<section class="project_listing_wrap pt_100 pb_100">
    <div class="container">
        <div class="filter_wraper">
        <div class="filter_search search-bar">
            <div class="search-field">
                <button class="icon_search"><img
                        src="<?php echo get_template_directory_uri(); ?>/images/search_filter.svg" alt="img"></button>
                <input type="text" placeholder="SEARCH">
            </div>

            <div class="category-field category_flex">
                <div class="select_cate">
                    <select name="categories" id="product_select">
                        <option value="category1" selected>BY PRODUCT</option>
                        <option value="category2">Product 1</option>
                        <option value="category3">Product 2</option>
                        <option value="category3">Product 3</option>
                        <option value="category3">Product 4</option>
                    </select>
                    <!-- SVG Arrow -->
                    <span class="select-arrow">
                        <img src="<?php echo get_template_directory_uri(); ?>/images/black_dropdown.svg" alt="img">
                    </span>
                </div>

                <div class="select_cate">
                    <select name="categories" id="category_select">
                        <option value="category1" selected>BY CATEGORY</option>
                        <option value="category2">Category 1</option>
                        <option value="category3">Category 2</option>
                        <option value="category3">Category 3</option>
                        <option value="category3">Category 4</option>
                    </select>
                    <!-- SVG Arrow -->
                    <span class="select-arrow">
                        <img src="<?php echo get_template_directory_uri(); ?>/images/black_dropdown.svg" alt="img">
                    </span>
                </div>
            </div>

        </div>
 <div class="result_found">
                <p>14 results found</p>
                <span class="project_pills">
                            Single Glaze with door
                        </span>
                        <span class="project_pills">
                            Government
                        </span>
                        <button class="project_pills clear_filter">
                            Clear Filter
                        </button>
            </div>
    </div>

        <div class="project_listing_grid">
            <a href="/project-detail" class="project_grid_box" data-aos="fade-up" data-aos-duration="1200" data-aos-once="true">
                <div class="project_gird_img">
                    <img src="<?php echo get_template_directory_uri(); ?>/images/project_img_1.png" alt="img">
                    <span class="project_pills pro_pill_top">
                        100% Sustainable
                    </span>
                    <div class="pill_pro_bottom">
                        <span class="project_pills">
                            Single Glaze with door
                        </span>
                        <span class="project_pills">
                            Government
                        </span>
                    </div>

                </div>
                <div class="project_title">
                    Government Qatar Rail
                </div>
                <p>The Symfony Double Glaze Glass Partition with Door is a precision-engineered architectural solution
                    that elevates spatial design...
                </p>
            </a>

            <a href="/project-detail" class="project_grid_box" data-aos="fade-up" data-aos-duration="1200" data-aos-once="true">
                <div class="project_gird_img">
                    <img src="<?php echo get_template_directory_uri(); ?>/images/project_img_2.png" alt="img">
                     <span class="project_pills pro_pill_top">
                        100% Sustainable
                    </span>
                    <div class="pill_pro_bottom">
                        <span class="project_pills">
                            Single Glaze with door
                        </span>
                        <span class="project_pills">
                            Government
                        </span>
                    </div>
                </div>
                <div class="project_title">
                    Government Qatar Rail
                </div>
                <p>The Symfony Double Glaze Glass Partition with Door is a precision-engineered architectural solution
                    that elevates spatial design...</p>
            </a>
            <a href="/project-detail" class="project_grid_box" data-aos="fade-up" data-aos-duration="1200" data-aos-once="true">
                <div class="project_gird_img">
                    <img src="<?php echo get_template_directory_uri(); ?>/images/project_img_3.png" alt="img">
                     <span class="project_pills pro_pill_top">
                        100% Sustainable
                    </span>
                    <div class="pill_pro_bottom">
                        <span class="project_pills">
                            Single Glaze with door
                        </span>
                        <span class="project_pills">
                            Government
                        </span>
                    </div>
                </div>
                <div class="project_title">
                    Government Qatar Rail
                </div>
                <p>The Symfony Double Glaze Glass Partition with Door is a precision-engineered architectural solution
                    that elevates spatial design...</p>
            </a>
            <a href="/project-detail" class="project_grid_box" data-aos="fade-up" data-aos-duration="1200" data-aos-once="true">
                <div class="project_gird_img">
                    <img src="<?php echo get_template_directory_uri(); ?>/images/project_img_4.png" alt="img">
                     <span class="project_pills pro_pill_top">
                        100% Sustainable
                    </span>
                    <div class="pill_pro_bottom">
                        <span class="project_pills">
                            Single Glaze with door
                        </span>
                        <span class="project_pills">
                            Government
                        </span>
                    </div>
                </div>
                <div class="project_title">
                    Government Qatar Rail
                </div>
                <p>The Symfony Double Glaze Glass Partition with Door is a precision-engineered architectural solution
                    that elevates spatial design...</p>
            </a>
            <a href="/project-detail" class="project_grid_box" data-aos="fade-up" data-aos-duration="1200" data-aos-once="true">
                <div class="project_gird_img">
                    <img src="<?php echo get_template_directory_uri(); ?>/images/project_img_5.png" alt="img">
                     <span class="project_pills pro_pill_top">
                        100% Sustainable
                    </span>
                    <div class="pill_pro_bottom">
                        <span class="project_pills">
                            Single Glaze with door
                        </span>
                        <span class="project_pills">
                            Government
                        </span>
                    </div>
                </div>
                <div class="project_title">
                    Government Qatar Rail
                </div>
                <p>The Symfony Double Glaze Glass Partition with Door is a precision-engineered architectural solution
                    that elevates spatial design...</p>
            </a>
            <a href="/project-detail" class="project_grid_box" data-aos="fade-up" data-aos-duration="1200" data-aos-once="true">
                <div class="project_gird_img">
                    <img src="<?php echo get_template_directory_uri(); ?>/images/project_img_6.png" alt="img">
                     <span class="project_pills pro_pill_top">
                        100% Sustainable
                    </span>
                    <div class="pill_pro_bottom">
                        <span class="project_pills">
                            Single Glaze with door
                        </span>
                        <span class="project_pills">
                            Government
                        </span>
                    </div>
                </div>
                <div class="project_title">
                    Government Qatar Rail
                </div>
                <p>The Symfony Double Glaze Glass Partition with Door is a precision-engineered architectural solution
                    that elevates spatial design...</p>
            </a>
        </div>
    </div>
</section>