<section class="address_sec pt_150 pb_150">
  <div class="container">
    <div class="address_grid">
      <div class="address_gridbox" data-aos="fade-up" data-aos-duration="1400" data-aos-once="true">
        <div class="address_img">
          <img src="<?php echo get_template_directory_uri(); ?>/images/address_img_1.png" alt="img">
        </div>
        <h4>Euro Head Office</h4>
        <a href="tel:+97142684667">+971 4 268 4667</a>
        <a class="address_email" href="mailto:info@europhonacoustics.com">info@europhonacoustics.com</a>
        <p>Al Shafar Investment Building; Suite 238,
          7A St – Al Quoz 1</p>
      </div>

      <div class="address_gridbox" data-aos="fade-up" data-aos-duration="1400" data-aos-once="true">
        <div class="address_img">
          <img src="<?php echo get_template_directory_uri(); ?>/images/address_img_2.png" alt="img">
        </div>
        <h4>Euro Systems Qatar</h4>
        <a href="tel:+97444506884">+974 4450 6884</a>
        <a class="address_email" href="mailto:info@europhonacoustics.com">info@europhonacoustics.com</a>
        <p>Building 177, Unit no 7,
          Zone 43, Street 340,
          Opposite of JBK Villa compound, Salwa Road,
          Doha Qatar.</p>
      </div>

      <div class="address_gridbox" data-aos="fade-up" data-aos-duration="1400" data-aos-once="true">
        <div class="address_img">
          <img src="<?php echo get_template_directory_uri(); ?>/images/address_img_3.png" alt="img">
        </div>
        <h4>Euro Systems KSA</h4>
        <a href="tel:+96611257703">+96611257703</a>
        <a class="address_email" href="mailto:info@europhonacoustics.com">info@europhonacoustics.com</a>
        <p>Kayes Tower,
          Office No 12, First Floor
          Salahuddin al Ayoubi Street, Malaz,
          Riyadh KSA.</p>
      </div>

    </div>
  </div>
</section>