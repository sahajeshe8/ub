<section class="contact_form pb_150 pt_150">
  <div class="container">
    <h2 class="f_56 color_white text_center" data-aos="fade-up" data-aos-duration="1400" data-aos-once="true">Enquire Now</h2>

  <div class="form_container" data-aos="fade-up" data-aos-duration="1400" data-aos-once="true">
      <form>
      <div class="form-row">
        <div class="form-group">
          <input type="text" placeholder="FIRST NAME*" name="firstName" required>
        </div>
        <div class="form-group">
          <input type="text" placeholder="LAST NAME*" name="lastName" required>
        </div>
      </div>

      <div class="form-row">
        <div class="form-group full-width">
          <input type="email" placeholder="EMAIL ADDRESS*" name="email" required>
        </div>
      </div>

      <div class="form-row">
        <div class="form-group full-width">
          <input type="tel" placeholder="CONTACT NUMBER*" name="phone" required>
        </div>
      </div>

      <div class="form-row">
        <div class="form-group full-width">
          <textarea placeholder="MESSAGE" name="message" rows="1"></textarea>
        </div>
      </div>

     <div class="text_center">
         <button type="submit" class="btn_style">SUBMIT</button>
     </div>
    </form>
  </div>
  </div>
</section>