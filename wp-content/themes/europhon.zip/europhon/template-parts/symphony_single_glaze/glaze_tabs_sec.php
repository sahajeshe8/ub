<section class="tabs_section_main pt_150 pb_150">
    <div class="container">
        <h2 class="f_56 mb_100 text_center" data-aos="fade-up" data-aos-duration="1200" data-aos-once="true">DESIGN OPTIONS</h2>

        <div class="main_row_tab d_flex" data-aos="fade-up" data-aos-duration="1200" data-aos-once="true">
            <!-- Tabs -->
            <div class="tab_design_left">
                <div class="tabs_design">
                    <button class="tab active" data-tab="style" id="styleTab">
                        STYLE
                    </button>
                    <button class="tab" data-tab="color" id="colorTab">
                        COLOR
                    </button>
                </div>
            </div>
            <div class="tabcontent_wrapper">
                <!-- Left side - Preview -->
                <div class="preview-section">

                    <div class="preview-container" id="previewContainer">
                        <!-- Style preview (default) -->
                        <div class="style-preview active" id="stylePreview">
                            <svg class="hexagon-svg" xmlns="http://www.w3.org/2000/svg" width="70" height="70"
                                viewBox="0 0 70 70">
                                <g clip-path="url(#clip0_1012_9673)">
                                    <path
                                        d="M35.0026 8.75C23.7268 8.75 14.5859 18.2933 14.5859 29.1667V58.3333C14.5859 59.1069 14.8932 59.8488 15.4402 60.3957C15.9872 60.9427 16.7291 61.25 17.5026 61.25H52.5026C53.2762 61.25 54.018 60.9427 54.565 60.3957C55.112 59.8488 55.4193 59.1069 55.4193 58.3333V29.1667C55.4193 18.2933 46.2784 8.75 35.0026 8.75Z"
                                        stroke="white" stroke-width="1" stroke-linecap="round"
                                        stroke-linejoin="round" />
                                    <path d="M14.5859 37.916H55.4193" stroke="white" stroke-width="1"
                                        stroke-linecap="round" stroke-linejoin="round" />
                                    <path d="M35 8.75V61.25" stroke="white" stroke-width="1" stroke-linecap="round"
                                        stroke-linejoin="round" />
                                </g>
                                <defs>
                                    <clipPath id="clip0_1012_9673">
                                        <rect width="70" height="70" />
                                    </clipPath>
                                </defs>
                            </svg>
                        </div>

                        <!-- Color preview -->
                        <div class="color-preview" id="colorPreview">
                            <img id="colorPreviewImage"
                                src="https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?w=800&h=600&fit=crop"
                                alt="Interior room" />
                        </div>
                    </div>
                </div>

                <!-- Right side - Options Grid -->
                <div class="options-section">
                    <!-- Style Options Grid -->
                    <div class="options-grid active" id="styleOptions">
                        <div class="option-item">
                            <button class="option-btn style-btn selected">
                                 <img class="check_tab" src="<?php echo get_template_directory_uri(); ?>/images/check_tab.svg" alt="check">
                                <svg xmlns="http://www.w3.org/2000/svg" width="70" height="70" viewBox="0 0 70 70">
                                    <g clip-path="url(#clip0_1012_9673)">
                                        <path
                                            d="M35.0026 8.75C23.7268 8.75 14.5859 18.2933 14.5859 29.1667V58.3333C14.5859 59.1069 14.8932 59.8488 15.4402 60.3957C15.9872 60.9427 16.7291 61.25 17.5026 61.25H52.5026C53.2762 61.25 54.018 60.9427 54.565 60.3957C55.112 59.8488 55.4193 59.1069 55.4193 58.3333V29.1667C55.4193 18.2933 46.2784 8.75 35.0026 8.75Z"
                                            stroke="white" stroke-width="1" stroke-linecap="round"
                                            stroke-linejoin="round" />
                                        <path d="M14.5859 37.916H55.4193" stroke="white" stroke-width="1"
                                            stroke-linecap="round" stroke-linejoin="round" />
                                        <path d="M35 8.75V61.25" stroke="white" stroke-width="1" stroke-linecap="round"
                                            stroke-linejoin="round" />
                                    </g>
                                    <defs>
                                        <clipPath id="clip0_1012_9673">
                                            <rect width="70" height="70" />
                                        </clipPath>
                                    </defs>
                                </svg>
                            </button>
                            <span class="option-label">Canyon</span>
                        </div>

                        <div class="option-item">
                            <button class="option-btn style-btn">
                                   <img class="check_tab" src="<?php echo get_template_directory_uri(); ?>/images/check_tab.svg" alt="check">
                                <svg xmlns="http://www.w3.org/2000/svg" width="70" height="70" viewBox="0 0 70 70">
                                    <g clip-path="url(#clip0_1012_9682)">
                                        <path
                                            d="M17.1996 58.881C22.0704 61.0743 28.5629 61.2493 35 61.2493C41.4371 61.2493 47.9325 61.0773 52.8033 58.881C55.335 57.7377 57.5108 56.0168 59.0246 53.4677C60.5237 50.9448 61.25 47.8093 61.25 44.0352C61.25 36.5189 58.3829 28.5331 53.7921 22.4052C49.2129 16.2977 42.6125 11.666 35 11.666C27.3875 11.666 20.7871 16.2977 16.2079 22.4052C11.6171 28.5331 8.75 36.5218 8.75 44.0352C8.75 47.8123 9.47625 50.9448 10.9754 53.4677C12.4892 56.0168 14.665 57.7377 17.1996 58.881Z"
                                            stroke="white" stroke-width="1" stroke-linecap="round"
                                            stroke-linejoin="round" />
                                    </g>
                                    <defs>
                                        <clipPath id="clip0_1012_9682">
                                            <rect width="70" height="70" />
                                        </clipPath>
                                    </defs>
                                </svg>
                            </button>
                            <span class="option-label">Terrace</span>
                        </div>

                        <div class="option-item">
                            <button class="option-btn style-btn">
                                     <img class="check_tab" src="<?php echo get_template_directory_uri(); ?>/images/check_tab.svg" alt="check">
                                <svg xmlns="http://www.w3.org/2000/svg" width="70" height="70" viewBox="0 0 70 70">
                                    <g clip-path="url(#clip0_1012_9689)">
                                        <path
                                            d="M57.9688 18.287C60.0104 19.4478 61.2646 21.6207 61.25 23.9686V45.2136C61.25 47.5732 59.9579 49.749 57.8725 50.8953L38.185 63.3495C37.2089 63.8851 36.1134 64.1659 35 64.1659C33.8866 64.1659 32.7911 63.8851 31.815 63.3495L12.1275 50.8953C11.1082 50.3365 10.2572 49.5147 9.66323 48.5155C9.06923 47.5162 8.75388 46.3761 8.75 45.2136V23.9657C8.75 21.6061 10.0421 19.4332 12.1275 18.287L31.815 6.67862C32.8199 6.12456 33.9487 5.83398 35.0963 5.83398C36.2438 5.83398 37.3726 6.12456 38.3775 6.67862L58.065 18.287H57.9688Z"
                                            stroke="white" stroke-width="1" stroke-linecap="round"
                                            stroke-linejoin="round" />
                                    </g>
                                    <defs>
                                        <clipPath id="clip0_1012_9689">
                                            <rect width="70" height="70" />
                                        </clipPath>
                                    </defs>
                                </svg>
                            </button>
                            <span class="option-label">Highland</span>
                        </div>

                        <div class="option-item">
                            <button class="option-btn style-btn">
                                    <img class="check_tab" src="<?php echo get_template_directory_uri(); ?>/images/check_tab.svg" alt="check">
                                <svg xmlns="http://www.w3.org/2000/svg" width="70" height="70" viewBox="0 0 70 70">
                                    <g clip-path="url(#clip0_1012_9696)">
                                        <path
                                            d="M34.9987 8.75C23.7229 8.75 14.582 18.2933 14.582 29.1667V58.3333C14.582 59.1069 14.8893 59.8488 15.4363 60.3957C15.9833 60.9427 16.7251 61.25 17.4987 61.25H52.4987C53.2722 61.25 54.0141 60.9427 54.5611 60.3957C55.1081 59.8488 55.4154 59.1069 55.4154 58.3333V29.1667C55.4154 18.2933 46.2745 8.75 34.9987 8.75Z"
                                            stroke="white" stroke-width="1" stroke-linecap="round"
                                            stroke-linejoin="round" />
                                        <path d="M14.582 37.916H55.4154" stroke="white" stroke-width="1"
                                            stroke-linecap="round" stroke-linejoin="round" />
                                        <path d="M35 8.75V61.25" stroke="white" stroke-width="1" stroke-linecap="round"
                                            stroke-linejoin="round" />
                                    </g>
                                    <defs>
                                        <clipPath id="clip0_1012_9696">
                                            <rect width="70" height="70" />
                                        </clipPath>
                                    </defs>
                                </svg>
                            </button>
                            <span class="option-label">Canyon</span>
                        </div>

                        <div class="option-item">
                            <button class="option-btn style-btn">
                                   <img class="check_tab" src="<?php echo get_template_directory_uri(); ?>/images/check_tab.svg" alt="check">
                                <svg xmlns="http://www.w3.org/2000/svg" width="70" height="70" viewBox="0 0 70 70">
                                    <g clip-path="url(#clip0_1012_9709)">
                                        <path
                                            d="M57.9688 18.287C60.0104 19.4478 61.2646 21.6207 61.25 23.9686V45.2136C61.25 47.5732 59.9579 49.749 57.8725 50.8953L38.185 63.3495C37.2089 63.8851 36.1134 64.1659 35 64.1659C33.8866 64.1659 32.7911 63.8851 31.815 63.3495L12.1275 50.8953C11.1082 50.3365 10.2572 49.5147 9.66323 48.5155C9.06923 47.5162 8.75388 46.3761 8.75 45.2136V23.9657C8.75 21.6061 10.0421 19.4332 12.1275 18.287L31.815 6.67862C32.8199 6.12456 33.9487 5.83398 35.0963 5.83398C36.2438 5.83398 37.3726 6.12456 38.3775 6.67862L58.065 18.287H57.9688Z"
                                            stroke="white" stroke-width="1" stroke-linecap="round"
                                            stroke-linejoin="round" />
                                    </g>
                                    <defs>
                                        <clipPath id="clip0_1012_9709">
                                            <rect width="70" height="70" />
                                        </clipPath>
                                    </defs>
                                </svg>
                            </button>
                            <span class="option-label">Highland</span>
                        </div>

                        <div class="option-item">
                            <button class="option-btn style-btn">
                                    <img class="check_tab" src="<?php echo get_template_directory_uri(); ?>/images/check_tab.svg" alt="check">
                                <svg xmlns="http://www.w3.org/2000/svg" width="70" height="70" viewBox="0 0 70 70">
                                    <g clip-path="url(#clip0_1012_9716)">
                                        <path
                                            d="M34.9987 8.75C23.7229 8.75 14.582 18.2933 14.582 29.1667V58.3333C14.582 59.1069 14.8893 59.8488 15.4363 60.3957C15.9833 60.9427 16.7251 61.25 17.4987 61.25H52.4987C53.2722 61.25 54.0141 60.9427 54.5611 60.3957C55.1081 59.8488 55.4154 59.1069 55.4154 58.3333V29.1667C55.4154 18.2933 46.2745 8.75 34.9987 8.75Z"
                                            stroke="white" stroke-width="1" stroke-linecap="round"
                                            stroke-linejoin="round" />
                                        <path d="M14.582 37.916H55.4154" stroke="white" stroke-width="1"
                                            stroke-linecap="round" stroke-linejoin="round" />
                                        <path d="M35 8.75V61.25" stroke="white" stroke-width="1" stroke-linecap="round"
                                            stroke-linejoin="round" />
                                    </g>
                                    <defs>
                                        <clipPath id="clip0_1012_9716">
                                            <rect width="70" height="70" />
                                        </clipPath>
                                    </defs>
                                </svg>
                            </button>
                            <span class="option-label">Canyon</span>
                        </div>

                        <div class="option-item">
                            <button class="option-btn style-btn">
                                     <img class="check_tab" src="<?php echo get_template_directory_uri(); ?>/images/check_tab.svg" alt="check">
                                <svg xmlns="http://www.w3.org/2000/svg" width="70" height="70" viewBox="0 0 70 70">
                                    <g clip-path="url(#clip0_1012_9725)">
                                        <path
                                            d="M17.1996 58.881C22.0704 61.0743 28.5629 61.2493 35 61.2493C41.4371 61.2493 47.9325 61.0773 52.8033 58.881C55.335 57.7377 57.5108 56.0168 59.0246 53.4677C60.5237 50.9448 61.25 47.8093 61.25 44.0352C61.25 36.5189 58.3829 28.5331 53.7921 22.4052C49.2129 16.2977 42.6125 11.666 35 11.666C27.3875 11.666 20.7871 16.2977 16.2079 22.4052C11.6171 28.5331 8.75 36.5218 8.75 44.0352C8.75 47.8123 9.47625 50.9448 10.9754 53.4677C12.4892 56.0168 14.665 57.7377 17.1996 58.881Z"
                                            stroke="white" stroke-width="1" stroke-linecap="round"
                                            stroke-linejoin="round" />
                                    </g>
                                    <defs>
                                        <clipPath id="clip0_1012_9725">
                                            <rect width="70" height="70" />
                                        </clipPath>
                                    </defs>
                                </svg>
                            </button>
                            <span class="option-label">Terrace</span>
                        </div>

                        <div class="option-item">
                            <button class="option-btn style-btn">
                                    <img class="check_tab" src="<?php echo get_template_directory_uri(); ?>/images/check_tab.svg" alt="check">
                                <svg xmlns="http://www.w3.org/2000/svg" width="70" height="70" viewBox="0 0 70 70">
                                    <g clip-path="url(#clip0_1012_9732)">
                                        <path
                                            d="M57.9688 18.287C60.0104 19.4478 61.2646 21.6207 61.25 23.9686V45.2136C61.25 47.5732 59.9579 49.749 57.8725 50.8953L38.185 63.3495C37.2089 63.8851 36.1134 64.1659 35 64.1659C33.8866 64.1659 32.7911 63.8851 31.815 63.3495L12.1275 50.8953C11.1082 50.3365 10.2572 49.5147 9.66323 48.5155C9.06923 47.5162 8.75388 46.3761 8.75 45.2136V23.9657C8.75 21.6061 10.0421 19.4332 12.1275 18.287L31.815 6.67862C32.8199 6.12456 33.9487 5.83398 35.0963 5.83398C36.2438 5.83398 37.3726 6.12456 38.3775 6.67862L58.065 18.287H57.9688Z"
                                            stroke="white" stroke-width="1" stroke-linecap="round"
                                            stroke-linejoin="round" />
                                    </g>
                                    <defs>
                                        <clipPath id="clip0_1012_9732">
                                            <rect width="70" height="70" />
                                        </clipPath>
                                    </defs>
                                </svg>
                            </button>
                            <span class="option-label">Highland</span>
                        </div>

                        <div class="option-item">
                            <button class="option-btn style-btn">
                                  <img class="check_tab" src="<?php echo get_template_directory_uri(); ?>/images/check_tab.svg" alt="check">
                                <svg xmlns="http://www.w3.org/2000/svg" width="70" height="70" viewBox="0 0 70 70">
                                    <g clip-path="url(#clip0_1012_9739)">
                                        <path
                                            d="M35 61.25C41.9619 61.25 48.6387 58.4844 53.5616 53.5616C58.4844 48.6387 61.25 41.9619 61.25 35C61.25 28.0381 58.4844 21.3613 53.5616 16.4384C48.6387 11.5156 41.9619 8.75 35 8.75C28.0381 8.75 21.3613 11.5156 16.4384 16.4384C11.5156 21.3613 8.75 28.0381 8.75 35C8.75 41.9619 11.5156 48.6387 16.4384 53.5616C21.3613 58.4844 28.0381 61.25 35 61.25Z"
                                            stroke="white" stroke-width="1" stroke-linecap="round"
                                            stroke-linejoin="round" />
                                        <path
                                            d="M23.3359 26.2507C23.3359 25.4771 23.6432 24.7352 24.1902 24.1883C24.7372 23.6413 25.4791 23.334 26.2526 23.334H43.7526C44.5262 23.334 45.268 23.6413 45.815 24.1883C46.362 24.7352 46.6693 25.4771 46.6693 26.2507V43.7507C46.6693 44.5242 46.362 45.2661 45.815 45.813C45.268 46.36 44.5262 46.6673 43.7526 46.6673H26.2526C25.4791 46.6673 24.7372 46.36 24.1902 45.813C23.6432 45.2661 23.3359 44.5242 23.3359 43.7507V26.2507Z"
                                            stroke="white" stroke-width="1" stroke-linecap="round"
                                            stroke-linejoin="round" />
                                    </g>
                                    <defs>
                                        <clipPath id="clip0_1012_9739">
                                            <rect width="70" height="70" />
                                        </clipPath>
                                    </defs>
                                </svg>
                            </button>
                            <span class="option-label">Caspian</span>
                        </div>
                    </div>

                    <!-- Color Options Grid -->
                    <div class="options-grid" id="colorOptions">
                        <div class="option-item">
                            <button class="option-btn color-btn selected" style="background-color: #C17A58;">
                                  <img class="check_tab" src="<?php echo get_template_directory_uri(); ?>/images/check_tab.svg" alt="check">
                            </button>
                            <span class="option-label">Canyon</span>
                        </div>

                        <div class="option-item">
                            <button class="option-btn color-btn" style="background-color: #A6948B;">
                                  <img class="check_tab" src="<?php echo get_template_directory_uri(); ?>/images/check_tab.svg" alt="check">
                            </button>
                            <span class="option-label">Terrace</span>
                        </div>

                        <div class="option-item">
                            <button class="option-btn color-btn" style="background-color: #B5A572;">
                                  <img class="check_tab" src="<?php echo get_template_directory_uri(); ?>/images/check_tab.svg" alt="check">
                            </button>
                            <span class="option-label">Highland</span>
                        </div>

                        <div class="option-item">
                            <button class="option-btn color-btn" style="background-color: #5F6A6A;">
                                  <img class="check_tab" src="<?php echo get_template_directory_uri(); ?>/images/check_tab.svg" alt="check">
                            </button>
                            <span class="option-label">Caspian</span>
                        </div>

                        <div class="option-item">
                            <button class="option-btn color-btn" style="background-color: #8B8589;">
                                  <img class="check_tab" src="<?php echo get_template_directory_uri(); ?>/images/check_tab.svg" alt="check">
                            </button>
                            <span class="option-label">Sage</span>
                        </div>

                        <div class="option-item">
                            <button class="option-btn color-btn" style="background-color: #5C2C2E;">
                                  <img class="check_tab" src="<?php echo get_template_directory_uri(); ?>/images/check_tab.svg" alt="check">
                            </button>
                            <span class="option-label">Maroon</span>
                        </div>

                        <div class="option-item">
                            <button class="option-btn color-btn" style="background-color: #E6B547;">
                                  <img class="check_tab" src="<?php echo get_template_directory_uri(); ?>/images/check_tab.svg" alt="check">
                            </button>
                            <span class="option-label">Senado</span>
                        </div>

                        <div class="option-item">
                            <button class="option-btn color-btn" style="background-color: #C9A960;">
                                  <img class="check_tab" src="<?php echo get_template_directory_uri(); ?>/images/check_tab.svg" alt="check">
                            </button>
                            <span class="option-label">Beehive</span>
                        </div>

                        <div class="option-item">
                            <button class="option-btn color-btn" style="background-color: #867C6F;">
                                  <img class="check_tab" src="<?php echo get_template_directory_uri(); ?>/images/check_tab.svg" alt="check">
                            </button>
                            <span class="option-label">Parthenon</span>
                        </div>

                        <div class="option-item">
                            <button class="option-btn color-btn" style="background-color: #D5C4B8;">
                                  <img class="check_tab" src="<?php echo get_template_directory_uri(); ?>/images/check_tab.svg" alt="check">
                            </button>
                            <span class="option-label">Opera</span>
                        </div>

                        <div class="option-item">
                            <button class="option-btn color-btn" style="background-color: #9AAF7E;">
                                  <img class="check_tab" src="<?php echo get_template_directory_uri(); ?>/images/check_tab.svg" alt="check">
                            </button>
                            <span class="option-label">Acros</span>
                        </div>

                        <div class="option-item">
                            <button class="option-btn color-btn" style="background-color: #2F3D1C;">
                                  <img class="check_tab" src="<?php echo get_template_directory_uri(); ?>/images/check_tab.svg" alt="check">
                            </button>
                            <span class="option-label">Gherkin</span>
                        </div>

                        <div class="option-item">
                            <button class="option-btn color-btn" style="background-color: #2C5145;">
                                  <img class="check_tab" src="<?php echo get_template_directory_uri(); ?>/images/check_tab.svg" alt="check">
                            </button>
                            <span class="option-label">Green</span>
                        </div>

                        <div class="option-item">
                            <button class="option-btn color-btn" style="background-color: #99C4C4;">
                                  <img class="check_tab" src="<?php echo get_template_directory_uri(); ?>/images/check_tab.svg" alt="check">
                            </button>
                            <span class="option-label">Teal</span>
                        </div>

                        <div class="option-item">
                            <button class="option-btn color-btn" style="background-color: #3D4E5C;">
                                  <img class="check_tab" src="<?php echo get_template_directory_uri(); ?>/images/check_tab.svg" alt="check">
                            </button>
                            <span class="option-label">Grey</span>
                        </div>

                        <div class="option-item">
                            <button class="option-btn color-btn" style="background-color: #1F2A36;">
                                  <img class="check_tab" src="<?php echo get_template_directory_uri(); ?>/images/check_tab.svg" alt="check">
                            </button>
                            <span class="option-label">Navy</span>
                        </div>

                        <div class="option-item">
                            <button class="option-btn color-btn" style="background-color: #8B7D4F;">
                                  <img class="check_tab" src="<?php echo get_template_directory_uri(); ?>/images/check_tab.svg" alt="check">
                            </button>
                            <span class="option-label">Highland</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>