
<section class="sub_page_banner radial_gradient" style="background-image: url('<?php echo get_template_directory_uri(); ?>/images/projects_page_banner.webp');">
   
    <div class="container">
      <div class="banner_nav_wraper">
        <div class="banner_bread_crumb">
            <div class="banner_bc_title pointer" data-aos="fade-right" data-aos-duration="1400" data-aos-once="true"><img src="<?php echo get_template_directory_uri(); ?>/images/caret_down.svg" alt="img"> Symfony Glass</div>
        </div>
      </div>
    </div>

    <div class="bread_crumb_header">
        <div class="container">
            <a href="" class="active">Symfony Glass</a>
            <a href="">Symfony Fabric</a>
            <a href="">Symfony Wall</a>
            <a href="">Symfony Ceiling</a>
            <a href="">Symfony Wave</a>
        </div>
    </div>
</section>

