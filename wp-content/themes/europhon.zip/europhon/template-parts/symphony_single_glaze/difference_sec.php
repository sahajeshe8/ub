<section class="service_difference">
    <img src="<?php echo get_template_directory_uri(); ?>/images/glaze_single_bg.webp" alt="img">

<!--     <div class="container">
      <h2 class="color_white f_56 text_center" data-aos="fade-up" data-aos-duration="1200" data-aos-once="true">Designed to blur the line between work, hospitality, and community</h2>
    </div> -->

  </section>