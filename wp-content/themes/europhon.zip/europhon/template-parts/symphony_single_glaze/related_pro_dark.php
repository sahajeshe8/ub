
<section class="related_dark pt_150 pb_150">
    <div class="container">
        <div class="related_dark_grid ">
            <div class="related_dark_col first_related_dark_grid">
               <div class="related_dark_inner" data-aos="fade-right" data-aos-duration="1200"  data-aos-once="true">
                 <h2>Related Products</h2>
                <p>Symfony® Glass is ideal for modern offices,
executive suites, and commercial spaces where
privacy and openness must coexist.</p>
               </div>
            </div>

             <div class="related_dark_col" data-aos="fade-up" data-aos-duration="1200"  data-aos-once="true">
               <a href="" class="related_dark_img">
                 <img src="<?php echo get_template_directory_uri(); ?>/images/preal_proj_i1.png" alt="img">
                    <h4>SINGLE GLAZED <br>WITH DOOR</h4>
               </a>
            </div>
 <div class="related_dark_col" data-aos="fade-up" data-aos-duration="1200"  data-aos-once="true">
               <a href="" class="related_dark_img">
                 <img src="<?php echo get_template_directory_uri(); ?>/images/preal_proj_i2.png" alt="img">
                    <h4>DOUBLE <br>GLAZED</h4>
               </a>
            </div>
             <div class="related_dark_col" data-aos="fade-up" data-aos-duration="1200"  data-aos-once="true">
               <a href="" class="related_dark_img">
                 <img src="<?php echo get_template_directory_uri(); ?>/images/preal_proj_i3.png" alt="img">
                    <h4>DOUBLE GLAZED <br>with door</h4>
               </a>
            </div>
        </div>
    </div>
</section>