    <section class="accordion_main_sec pt_100 pb_100">
        <div class="container">

            <div class="accordion" id="accordionExample" data-aos="fade-up" data-aos-duration="1200" data-aos-once="true">
                <div class="accordion-item">
                    <h2 class="accordion-header">
                        <button class="accordion-button">
                           <h4>Chief Financial Officer</h4>
                         <span class="accordion-icon">
                            
          <img src="https://europhon-dev.e8demo.com/wp-content/themes/europhon/images/accord_minus.svg" alt="minus">
        </span>
                        </button>
                    </h2>
                    <div class="accordion-collapse">
                        <div class="accordion-body">
                            <div class="content_accordion">
                                <div class="accordion_row d_flex">
                                    <div class="accordion_row_l">
                                        <h4>Job Roles & Responsibilities </h4>
                                    </div>
                                    <div class="accordion_row_r">
                                        <ul>
                                            <li>Archive and control revisions of design drawings, shop drawings, and
                                                as-builts.
                                            </li>
                                            <li>Must have a experience in CAD drafting/design experience in civil
                                                infrastructure projects roads, bridges, utilities, manholes,
                                                landscaping,
                                                etc.
                                            </li>
                                            <li>Must be fluent in English with an excellent understanding of technical
                                                terminology.
                                            </li>
                                            <li>Civil AutoCAD drafters have to draw diagrams and maps for projects and
                                                structures in construction.</li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="accordion_row d_flex">
                                    <div class="accordion_row_l">
                                        <h4>Skill Sets Required :</h4>
                                    </div>
                                    <div class="accordion_row_r">
                                        <ul>
                                            <li>Drafting Skill</li>
                                            <li>Computer Skill</li>
                                            <li>Collaboration Skill</li>
                                            <li>Attention to Details</li>
                                            <li>Communication Skill</li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="accordion_row d_flex">
                                    <div class="accordion_row_l">
                                        <h4>Qualifications :</h4>
                                    </div>
                                    <div class="accordion_row_r">
                                        <ul>
                                            <li class="bold_listing">Minimum Education:<br>
                                                <span>Diploma/Bachelor degree/ ITI</span>
                                            </li>
                                            <li class="bold_listing">Minimum Experience Required:<br>
                                                <span>3- 10 years experience </span>
                                            </li>
                                            <li class="bold_listing">Software Knowledge:<br>
                                                <span>Civil 3D</span><br>
                                                <span>AutoCAD</span>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="apply_btn">
                                    <a href="#" class="btn_style btn_black apply-now-btn" data-job-title="Chief Financial Officer">Apply Now</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Apply Now Modal -->
                <div id="applyModal" class="apply-modal">
                    <div class="apply-modal-overlay"></div>
                    <div class="apply-modal-content">
                        <button class="apply-modal-close" aria-label="Close">
                            <img src="<?php echo get_template_directory_uri(); ?>/images/close-icn.svg" alt="Close">
                        </button>
                        <h2 class="apply-modal-title">Apply Now</h2>
                        <form class="apply-form" id="applyForm">
                            <ul class="apply-form-list">
                                <li class="apply-form-item apply-form-row">
                                    <div class="apply-form-group">
                                        <input type="text" name="firstName" placeholder="FIRST NAME*" required>
                                    </div>
                                    <div class="apply-form-group">
                                        <input type="text" name="lastName" placeholder="LAST NAME*" required>
                                    </div>
                                </li>
                                <li class="apply-form-item">
                                    <div class="apply-form-group">
                                        <input type="email" name="email" placeholder="EMAIL ADDRESS*" required>
                                    </div>
                                </li>
                                <li class="apply-form-item">
                                    <div class="apply-form-group">
                                        <input type="tel" name="phone" placeholder="CONTACT NUMBER*" required>
                                    </div>
                                </li>
                                <li class="apply-form-item">
                                    <div class="apply-form-group">
                                        <input type="text" name="city" placeholder="CITY*" required>
                                    </div>
                                </li>
                                <li class="apply-form-item">
                                    <div class="apply-form-group">
                                        <input type="url" name="linkedin" placeholder="LINKEDIN URL*" required>
                                    </div>
                                </li>
                                <li class="apply-form-item">
                                    <div class="apply-form-group">
                                        <div class="file-upload-wrapper">
                                            <input type="file" name="resume" accept=".pdf,.doc,.docx" required>
                                            <span class="file-upload-text">ATTACH RESUME*</span>
                                            <span class="file-upload-icon">
                                                <img src="<?php echo get_template_directory_uri(); ?>/images/attach-icn.svg" alt="Attach">
                                            </span>
                                        </div>
                                    </div>
                                </li>
                            </ul>
                            <div class="apply-form-submit">
                                <button type="submit" class="btn_style btn_white">APPLY</button>
                            </div>
                        </form>
                    </div>
                </div>

                <div class="accordion-item">
                    <h2 class="accordion-header">
                        <button class="accordion-button collapsed">
                          <h4>Design Manager</h4>
                         <span class="accordion-icon">
          <img src="https://europhon-dev.e8demo.com/wp-content/themes/europhon/images/accord_plus.svg" alt="plus">
        </span>
                        </button>
                    </h2>
                    <div class="accordion-collapse">
                        <div class="accordion-body">
                            <div class="content_accordion">
                                <div class="accordion_row d_flex">
                                    <div class="accordion_row_l">
                                        <h4>Job Roles & Responsibilities </h4>
                                    </div>
                                    <div class="accordion_row_r">
                                        <ul>
                                            <li>Archive and control revisions of design drawings, shop drawings, and
                                                as-builts.
                                            </li>
                                            <li>Must have a experience in CAD drafting/design experience in civil
                                                infrastructure projects roads, bridges, utilities, manholes,
                                                landscaping,
                                                etc.
                                            </li>
                                            <li>Must be fluent in English with an excellent understanding of technical
                                                terminology.
                                            </li>
                                            <li>Civil AutoCAD drafters have to draw diagrams and maps for projects and
                                                structures in construction.</li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="accordion_row d_flex">
                                    <div class="accordion_row_l">
                                        <h4>Skill Sets Required :</h4>
                                    </div>
                                    <div class="accordion_row_r">
                                        <ul>
                                            <li>Drafting Skill</li>
                                            <li>Computer Skill</li>
                                            <li>Collaboration Skill</li>
                                            <li>Attention to Details</li>
                                            <li>Communication Skill</li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="accordion_row d_flex">
                                    <div class="accordion_row_l">
                                        <h4>Qualifications :</h4>
                                    </div>
                                    <div class="accordion_row_r">
                                        <ul>
                                            <li class="bold_listing">Minimum Education:<br>
                                                <span>Diploma/Bachelor degree/ ITI</span>
                                            </li>
                                            <li class="bold_listing">Minimum Experience Required:<br>
                                                <span>3- 10 years experience </span>
                                            </li>
                                            <li class="bold_listing">Software Knowledge:<br>
                                                <span>Civil 3D</span><br>
                                                <span>AutoCAD</span>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="apply_btn">
                                    <a href="#" class="btn_style btn_black apply-now-btn" data-job-title="Design Manager">Apply Now</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="accordion-item">
                    <h2 class="accordion-header">
                        <button class="accordion-button collapsed">
                            <h4>Project Coordinator</h4>
                          <span class="accordion-icon">
          <img src="https://europhon-dev.e8demo.com/wp-content/themes/europhon/images/accord_plus.svg" alt="plus">
        </span>
                        </button>
                    </h2>
                    <div class="accordion-collapse">
                        <div class="accordion-body">
                            <div class="content_accordion">
                                <div class="accordion_row d_flex">
                                    <div class="accordion_row_l">
                                        <h4>Job Roles & Responsibilities </h4>
                                    </div>
                                    <div class="accordion_row_r">
                                        <ul>
                                            <li>Archive and control revisions of design drawings, shop drawings, and
                                                as-builts.
                                            </li>
                                            <li>Must have a experience in CAD drafting/design experience in civil
                                                infrastructure projects roads, bridges, utilities, manholes,
                                                landscaping,
                                                etc.
                                            </li>
                                            <li>Must be fluent in English with an excellent understanding of technical
                                                terminology.
                                            </li>
                                            <li>Civil AutoCAD drafters have to draw diagrams and maps for projects and
                                                structures in construction.</li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="accordion_row d_flex">
                                    <div class="accordion_row_l">
                                        <h4>Skill Sets Required :</h4>
                                    </div>
                                    <div class="accordion_row_r">
                                        <ul>
                                            <li>Drafting Skill</li>
                                            <li>Computer Skill</li>
                                            <li>Collaboration Skill</li>
                                            <li>Attention to Details</li>
                                            <li>Communication Skill</li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="accordion_row d_flex">
                                    <div class="accordion_row_l">
                                        <h4>Qualifications :</h4>
                                    </div>
                                    <div class="accordion_row_r">
                                        <ul>
                                            <li class="bold_listing">Minimum Education:<br>
                                                <span>Diploma/Bachelor degree/ ITI</span>
                                            </li>
                                            <li class="bold_listing">Minimum Experience Required:<br>
                                                <span>3- 10 years experience </span>
                                            </li>
                                            <li class="bold_listing">Software Knowledge:<br>
                                                <span>Civil 3D</span><br>
                                                <span>AutoCAD</span>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="apply_btn">
                                    <a href="#" class="btn_style btn_black apply-now-btn" data-job-title="Project Coordinator">Apply Now</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>