<section class="who_we_are sm_padding">
    <div class="container">
        <div class="text_center service_about">
            <h2 class="f_56" data-aos="fade-up" data-aos-duration="1200" data-aos-once="true">Join US</h2>
            <p class="f_20 mt_40" data-aos="fade-up" data-aos-duration="1200" data-aos-once="true">The Symfony Single Glaze Glass Partition System is a precision-engineered architectural solution that harmoniously blends technical excellence
with refined luxury. Featuring high-grade single glazing and minimal aluminum profiles, it delivers effective acoustic attenuation alongside
uninterrupted transparency. Every element is meticulously crafted to create light-filled, connected spaces that retain the hush of privacy, ensuring
both openness and discretion. Its tailored finishes and flawless detailing make it an ideal choice for offices, executive suites, and modern
commercial environments where design sophistication and functional performance must coexist. Symfony is more than a partition—it is an
architectural statement of precision, elegance, and quiet confidence.</p>
        </div>
    </div>
</section>