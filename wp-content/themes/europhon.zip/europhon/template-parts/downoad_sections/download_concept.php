<section class="download_concept">
    <div class="container">
        <div class="concept_row">
            <h2 class="f_55" data-aos="fade-up" data-aos-duration="1400" data-aos-once="true">From concept to completion
                – the files you need</h2>

            <div class="grid_conecpt">
                <div class="concept_box" data-aos="fade-up" data-aos-duration="1400" data-aos-once="true">
                    <h6>SUSTAINABILITY</h6>
                    <ul>
                        <li><a href="#">Sustainability Certificate1</a></li>
                        <li><a href="#">Sustainability Certificate1</a></li>
                        <li><a href="#">Sustainability Certificate1</a></li>
                        <li><a href="#">Sustainability Certificate1</a></li>
                        <li><a href="#">Sustainability Certificate1</a></li>
                        <li><a href="#">Sustainability Certificate1</a></li>
                    </ul>
                </div>

                <div class="concept_box" data-aos="fade-up" data-aos-duration="1400" data-aos-once="true">
                    <h6>FIRE TESTING</h6>
                    <ul>
                        <li><a href="#">Sustainability Certificate1</a></li>
                        <li><a href="#">Sustainability Certificate1</a></li>
                        <li><a href="#">Sustainability Certificate1</a></li>
                        <li><a href="#">Sustainability Certificate1</a></li>
                        <li><a href="#">Sustainability Certificate1</a></li>
                    </ul>
                </div>

                <div class="concept_box" data-aos="fade-up" data-aos-duration="1400" data-aos-once="true">
                    <h6>PRODUCT</h6>
                    <ul>
                        <li><a href="#">Europhon Warranty</a></li>
                        <li><a href="#">Cleaning Guide</a></li>
                        <li><a href="#">Product guide 1</a></li>
                    </ul>
                </div>
            </div>
        </div>

        <div class="concept_row">
            <h2 class="f_55" data-aos="fade-up" data-aos-duration="1400" data-aos-once="true">Materials Library</h2>

            <div class="grid_conecpt mb_0" data-aos="fade-up" data-aos-duration="1400" data-aos-once="true">
                <div class="concept_box">
                    <ul>
                        <li><a href="#">Color Guide</a></li>
                        <li><a href="#">Texture</a></li>
                        <li><a href="#">Finishes</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="download_glass pt_150 pb_150">
    <div class="container">
        <div class="concept_row">
            <h2 class="f_55" data-aos="fade-up" data-aos-duration="1400" data-aos-once="true">download_glass</h2>

            <div class="pill_row d_flex" data-aos="fade-up" data-aos-duration="1400" data-aos-once="true">
                <p>Single glazed</p>
                <button class="download_pill">Datasheet</button>
                <button class="download_pill">Brochure</button>
                <button class="download_pill">DWG</button>
            </div>
            <div class="pill_row d_flex" data-aos="fade-up" data-aos-duration="1400" data-aos-once="true">
                <p>Single glazed with door</p>
                <button class="download_pill">Datasheet</button>
                <button class="download_pill">Brochure</button>
                <button class="download_pill">DWG</button>
            </div>
            <div class="pill_row d_flex" data-aos="fade-up" data-aos-duration="1400" data-aos-once="true">
                <p>Double glazed</p>
                <button class="download_pill">Datasheet</button>
                <button class="download_pill">Brochure</button>
                <button class="download_pill">DWG</button>
            </div>
            <div class="pill_row d_flex" data-aos="fade-up" data-aos-duration="1400" data-aos-once="true">
                <p>Double glazed with door</p>
                <button class="download_pill">Datasheet</button>
                <button class="download_pill">Brochure</button>
                <button class="download_pill">DWG</button>
            </div>
        </div>

        <div class="concept_row">
            <h2 class="f_55" data-aos="fade-up" data-aos-duration="1400" data-aos-once="true">Symfony Fabric</h2>
            <div class="pill_row d_flex" data-aos="fade-up" data-aos-duration="1400" data-aos-once="true">
                <p>Acoustic Fabric Panel</p>
                <button class="download_pill">Datasheet</button>
                <button class="download_pill">Brochure</button>
                <button class="download_pill">DWG</button>
            </div>
            <div class="pill_row d_flex" data-aos="fade-up" data-aos-duration="1400" data-aos-once="true">
                <p>Acoustic Curtain</p>
                <button class="download_pill">Datasheet</button>
                <button class="download_pill">Brochure</button>
                <button class="download_pill">DWG</button>
            </div>
            <div class="pill_row d_flex" data-aos="fade-up" data-aos-duration="1400" data-aos-once="true">
                <p>Acoustic Curtain Divider</p>
                <button class="download_pill">Datasheet</button>
                <button class="download_pill">Brochure</button>
                <button class="download_pill">DWG</button>
            </div>
        </div>

        <div class="concept_row">
            <h2 class="f_55" data-aos="fade-up" data-aos-duration="1400" data-aos-once="true">Symfony Wall</h2>
            <div class="pill_row d_flex" data-aos="fade-up" data-aos-duration="1400" data-aos-once="true">
                <p>Movable Wall Partitions</p>
                <button class="download_pill">Datasheet</button>
                <button class="download_pill">Brochure</button>
                <button class="download_pill">DWG</button>
            </div>
            <div class="pill_row d_flex" data-aos="fade-up" data-aos-duration="1400" data-aos-once="true">
                <p>Soundwall</p>
                <button class="download_pill">Datasheet</button>
                <button class="download_pill">Brochure</button>
                <button class="download_pill">DWG</button>
            </div>
            <div class="pill_row d_flex" data-aos="fade-up" data-aos-duration="1400" data-aos-once="true">
                <p>Polysound</p>
                <button class="download_pill">Datasheet</button>
                <button class="download_pill">Brochure</button>
                <button class="download_pill">DWG</button>
            </div>
        </div>

        <div class="concept_row">
            <h2 class="f_55" data-aos="fade-up" data-aos-duration="1400" data-aos-once="true">Symfony Ceiling</h2>
            <div class="pill_row d_flex" data-aos="fade-up" data-aos-duration="1400" data-aos-once="true">
                <p>Melo</p>
                <button class="download_pill">Datasheet</button>
                <button class="download_pill">Brochure</button>
                <button class="download_pill">DWG</button>
            </div>
            <div class="pill_row d_flex" data-aos="fade-up" data-aos-duration="1400" data-aos-once="true">
                <p>Acoustical Spray</p>
                <button class="download_pill">Datasheet</button>
                <button class="download_pill">Brochure</button>
                <button class="download_pill">DWG</button>
            </div>
            <div class="pill_row d_flex" data-aos="fade-up" data-aos-duration="1400" data-aos-once="true">
                <p>Symfony Tile - Clip in</p>
                <button class="download_pill">Datasheet</button>
                <button class="download_pill">Brochure</button>
                <button class="download_pill">DWG</button>
            </div>
            <div class="pill_row d_flex" data-aos="fade-up" data-aos-duration="1400" data-aos-once="true">
                <p>Symfony Tile - Lay in</p>
                <button class="download_pill">Datasheet</button>
                <button class="download_pill">Brochure</button>
                <button class="download_pill">DWG</button>
            </div>
            <div class="pill_row d_flex" data-aos="fade-up" data-aos-duration="1400" data-aos-once="true">
                <p>Symfony Tile - Linear Baffle</p>
                <button class="download_pill">Datasheet</button>
                <button class="download_pill">Brochure</button>
                <button class="download_pill">DWG</button>
            </div>
        </div>

        <div class="concept_row">
            <h2 class="f_55" data-aos="fade-up" data-aos-duration="1400" data-aos-once="true">Symfony Wave</h2>
            <div class="pill_row d_flex" data-aos="fade-up" data-aos-duration="1400" data-aos-once="true">
                <p>Baffle</p>
                <button class="download_pill">Datasheet</button>
                <button class="download_pill">Brochure</button>
                <button class="download_pill">DWG</button>
            </div>
            <div class="pill_row d_flex" data-aos="fade-up" data-aos-duration="1400" data-aos-once="true">
                <p>PET Panels</p>
                <button class="download_pill">Datasheet</button>
                <button class="download_pill">Brochure</button>
                <button class="download_pill">DWG</button>
            </div>
        </div>
    </div>
</section>