


<section class="who_we_are sm_padding">
    <div class="container">
        <div class="text_center service_about">
            <h6 data-aos="fade-up" data-aos-duration="1200" data-aos-once="true">TRANSFORMING INTERIORS
                <br>THROUGH MINIMAL DESIGN AND
                <br>MAXIMUM PERFORMANCE</h6>

            <div class="text_center mt_60" data-aos="fade-up" data-aos-duration="1200" data-aos-once="true">
                <a href="" class="btn_style btn_outline">MAKE AN ENQUIRY</a>
            </div>
        </div>
    </div>
</section>