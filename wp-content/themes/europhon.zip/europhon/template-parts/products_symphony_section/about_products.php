

<section class="who_we_are sm_padding">
    <div class="container">
        <div class="text_center service_about">
            <h1 class="f_56" data-aos="fade-up" data-aos-duration="1200" data-aos-once="true">Symfony® Glass</h1>
            <p class="f_20 mt_40" data-aos="fade-up" data-aos-duration="1200" data-aos-once="true">Symfony Acoustic Glass Partitions Systems are designed for transparency without compromise. Symfony® Acoustic Glass partitions bring
clarity, openness, and acoustic control into one seamless system. Available in single-glazed and double-glazed options, these partitions
are engineered with minimal profiles (as slim as 25mm), ensuring uninterrupted visual flow while maintaining superior sound attenuation.
With integrated door systems, frameless joints, and tailored finishes. Symfony® Glass is ideal for modern offices, executive suites, and
commercial spaces where privacy and openness must coexist.</p>
        </div>
    </div>
</section>