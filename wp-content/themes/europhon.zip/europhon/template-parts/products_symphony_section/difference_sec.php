<section class="service_difference">
    <img src="<?php echo get_template_directory_uri(); ?>/images/symphony_difference.webp" alt="img">

    <div class="container">
      <h2 class="color_white f_56 text_center" data-aos="fade-up" data-aos-duration="1200" data-aos-once="true">CREATING HARMONY BETWEEN DESIGN,
FUNCTION, AND SILENCE</h2>
    </div>

  </section>