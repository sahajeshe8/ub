<section class="divider-main testimonial_main">
    <div class="dividers-banner"
        style="background-image: url('<?php echo get_template_directory_uri(); ?>/images/product_glass_bg_1.webp');">
        <div class="container">
            <div class="glass-card" data-aos="fade-up" data-aos-duration="1200" data-aos-once="true">
                <div class="card-header">
                    <h2>Testimonials</h2>
                    <span class="slide-count">1/3</span>
                </div>

                <div class="card_body">
                    <p class="description">
                        Sleek, modern aesthetic with clean lines and minimal visual interruption. Enhances architectural
                        elegance and maximizes natural light flow.
                    </p>

                    <div class="reviewer">
                        <div class="reviewer_name">Peter George</div>
                        <div class="reviewer_designation">CEO QATAR RAILS</div>
                    </div>

                </div>
            </div>
        </div>
    </div>
    <div class="dividers-banner"
        style="background-image: url('<?php echo get_template_directory_uri(); ?>/images/product_glass_bg_2.webp');">
        <div class="container">
            <div class="glass-card" data-aos="fade-up" data-aos-duration="1200" data-aos-once="true">
                <div class="card-header">
                    <h2>Testimonials</h2>
                    <span class="slide-count">2/3</span>
                </div>

                <div class="card_body">
                    <p class="description">
                        Sleek, modern aesthetic with clean lines and minimal visual interruption. Enhances architectural
                        elegance and maximizes natural light flow.
                    </p>
                    <div class="reviewer">
                        <div class="reviewer_name">Peter George</div>
                        <div class="reviewer_designation">CEO QATAR RAILS</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="dividers-banner"
        style="background-image: url('<?php echo get_template_directory_uri(); ?>/images/product_glass_bg_3.webp');">
        <div class="container">
            <div class="glass-card" data-aos="fade-up" data-aos-duration="1200" data-aos-once="true">
                <div class="card-header">
                    <h2>Testimonials</h2>
                    <span class="slide-count">3/3</span>
                </div>

                <div class="card_body">
                    <p class="description">
                        Sleek, modern aesthetic with clean lines and minimal visual interruption. Enhances architectural
                        elegance and maximizes natural light flow.
                    </p>

                    <div class="reviewer">
                        <div class="reviewer_name">Peter George</div>
                        <div class="reviewer_designation">CEO QATAR RAILS</div>
                    </div>
                </div>
            </div>
        </div>
    </div>


</section>