<section class="project_listing_wrap product_project pt_150 pb_150 bg_grey">
    <div class="container">
       <h2 class="f_56" data-aos="fade-right" data-aos-duration="1200" data-aos-once="true">Related Projects</h2>

        <div class="project_product_grid">
            <a href="" class="project_grid_box" data-aos="fade-up" data-aos-duration="1200" data-aos-once="true">
                <div class="project_gird_img">
                    <img src="<?php echo get_template_directory_uri(); ?>/images/product_img_1.png" alt="img">
                    <span class="project_pills pro_pill_top">
                        100% Sustainable
                    </span>
                    <div class="pill_pro_bottom">
                        <span class="project_pills">
                            Single Glaze with door
                        </span>
                        <span class="project_pills">
                            Government
                        </span>
                    </div>

                </div>
                <div class="project_title">
                    Government Qatar Rail
                </div>
                <p>The Symfony Double Glaze Glass Partition with Door is a precision-engineered architectural solution
                    that elevates spatial design...
                </p>
            </a>

            <a href="" class="project_grid_box" data-aos="fade-up" data-aos-duration="1200" data-aos-once="true">
                <div class="project_gird_img">
                    <img src="<?php echo get_template_directory_uri(); ?>/images/product_img_2.png" alt="img">
                     <span class="project_pills pro_pill_top">
                        100% Sustainable
                    </span>
                    <div class="pill_pro_bottom">
                        <span class="project_pills">
                            Single Glaze with door
                        </span>
                        <span class="project_pills">
                            Government
                        </span>
                    </div>
                </div>
                <div class="project_title">
                    Government Qatar Rail
                </div>
                <p>The Symfony Double Glaze Glass Partition with Door is a precision-engineered architectural solution
                    that elevates spatial design...</p>
            </a>
            <a href="" class="project_grid_box" data-aos="fade-up" data-aos-duration="1200" data-aos-once="true">
                <div class="project_gird_img">
                    <img src="<?php echo get_template_directory_uri(); ?>/images/product_img_3.png" alt="img">
                     <span class="project_pills pro_pill_top">
                        100% Sustainable
                    </span>
                    <div class="pill_pro_bottom">
                        <span class="project_pills">
                            Single Glaze with door
                        </span>
                        <span class="project_pills">
                            Government
                        </span>
                    </div>
                </div>
                <div class="project_title">
                    Government Qatar Rail
                </div>
                <p>The Symfony Double Glaze Glass Partition with Door is a precision-engineered architectural solution
                    that elevates spatial design...</p>
            </a>
      
        </div>

        <div class="text_center mt_60" data-aos="fade-up" data-aos-duration="1200" data-aos-once="true">
            <a href="" class="btn_style btn_cyan">Discover More</a>
        </div>
    </div>
</section>