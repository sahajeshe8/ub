

 <section class="project_detail_slider pb_150 pt_150">
    <div class="container">
          <div class="news_d_slider project_d_slider" data-aos="fade-up" data-aos-duration="1400" data-aos-once="true">
        <div class="news_d_slider_box">
          <img src="<?php echo get_template_directory_uri(); ?>/images/project_d_slider_img_1.webp" alt="img">
        </div>
        <div class="news_d_slider_box">
          <img src="<?php echo get_template_directory_uri(); ?>/images/project_d_slider_img_1.webp" alt="img">
        </div>
        <div class="news_d_slider_box">
          <img src="<?php echo get_template_directory_uri(); ?>/images/project_d_slider_img_1.webp" alt="img">
        </div>
        <div class="news_d_slider_box">
          <img src="<?php echo get_template_directory_uri(); ?>/images/project_d_slider_img_1.webp" alt="img">
        </div>
      </div>
    </div>
 </section>