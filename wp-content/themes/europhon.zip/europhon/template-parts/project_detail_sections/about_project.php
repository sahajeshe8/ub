<section class="project_about pb_150 pt_150">
    <div class="container">
        <div class="text_center project_d_about">
            <h2 class="f_56" data-aos="fade-up" data-aos-duration="1200" data-aos-once="true">The Project</h2>
            <p class="f_20 mt_40" data-aos="fade-up" data-aos-duration="1200" data-aos-once="true">Symfony® Acoustic Glass Partitions Systems are designed for transparency without compromise. Symfony® Acoustic Glass partitions bring clarity, openness, and acoustic control into one seamless system. Available in single and double-glazed options, these partitions are engineered with minimal profiles of 25mm, ensuring uninterrupted visual flow while maintaining superior sound attenuation. With integrated door systems, frameless joints, and tailored finishes, Symfony® Glass is ideal for modern offices, executive suites, and commercial spaces. Where enhanced acoustics and privacy can coexist.</p>
        </div>
    </div>
</section>