<section class="additional_info pb_100 pt_100">
    <div class="container">
      <div class="additional_title" data-aos="fade-up" data-aos-duration="1200"  data-aos-once="true">
        Additional Information
      </div>
      <div class="addidtional_wrper" data-aos="fade-up" data-aos-duration="1200"  data-aos-once="true">
        <div class="additional_box">
            <ul>
                <li class="d_flex">
                    <p>Date:</p>
                    <p>January 11, 2025</p>
                </li>
                <li class="d_flex">
                    <p>Location:</p>
                    <p>Dubai, United Arab Emirates</p>
                </li>
                <li class="d_flex">
                    <p>Architect:</p>
                    <p>Murphy Meyers</p>
                </li>
                <li class="d_flex">
                    <p>Categories:</p>
                    <p>Government</p>
                </li>
            </ul>
        </div>
      </div>
    </div>
</section>