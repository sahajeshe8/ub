 <section class="home_slider_new">
 <div class="home_slider_new_col_01">
    <div class="swiper slider-col-01">
        <div class="swiper-wrapper">
            <div class="swiper-slide">
                <div class="slide-content">
                    

             
                <img src="<?php echo get_template_directory_uri(); ?>/images/home-slider-01.jpg" alt="Home Slider 01" />
                </div>
            </div>
            <div class="swiper-slide">
                <div class="slide-content">
                <img src="<?php echo get_template_directory_uri(); ?>/images/home-slider-01.jpg" alt="Home Slider 01" />
                </div>
            </div>
            <div class="swiper-slide">
                <div class="slide-content">
                <img src="<?php echo get_template_directory_uri(); ?>/images/home-slider-01.jpg" alt="Home Slider 01" />
                </div>
            </div>
        </div>
        <!-- Navigation arrows -->
        <!-- <div class="swiper-button-next"></div>
        <div class="swiper-button-prev"></div> -->
    </div>
 </div>

 <div class="home_slider_new_col_02">
    <div class="swiper slider-col-02">
        <div class="swiper-wrapper">
            <div class="swiper-slide">
                <div class="slide-content">
                    <h3>Symfony® Glass   </h3>
                    <h4>sleek modern transparency</h4>
                    <p>Symfony® acoustic glass partitions systems are designed for transparency without compromise. Symfony® acoustic glass partitions bring clarity, openness, and acoustic control into one seamless system.</p>     
                </div>
            </div>
            <div class="swiper-slide">
            <div class="slide-content">
                    <h3>Symfony® Glass   </h3>
                    <h4>sleek modern transparency</h4>
                    <p>Symfony® acoustic glass partitions systems are designed for transparency without compromise. Symfony® acoustic glass partitions bring clarity, openness, and acoustic control into one seamless system.</p>     
                </div>
            </div>
            <div class="swiper-slide">
            <div class="slide-content">
                    <h3>Symfony® Glass   </h3>
                    <h4>sleek modern transparency</h4>
                    <p>Symfony® acoustic glass partitions systems are designed for transparency without compromise. Symfony® acoustic glass partitions bring clarity, openness, and acoustic control into one seamless system.</p>     
                </div>
            </div>
        </div>
        <!-- Navigation arrows -->
        <!-- <div class="swiper-button-next"></div>
        <div class="swiper-button-prev"></div> -->
    </div>
 </div>

 <div class="home_slider_new_col_03">
    <div class="swiper slider-col-03">
        <div class="swiper-wrapper">
            <div class="swiper-slide">
                <div class="slide-content">
                <img src="<?php echo get_template_directory_uri(); ?>/images/sym-img-2-small.jpg" alt="Home Slider 01" />
                </div>
            </div>
            <div class="swiper-slide">
                <div class="slide-content">
                <img src="<?php echo get_template_directory_uri(); ?>/images/sym-img-2-small.jpg" alt="Home Slider 01" />
                </div>
            </div>
            <div class="swiper-slide">
                <div class="slide-content">
                    <div class="slide-content-inner">
                <img src="<?php echo get_template_directory_uri(); ?>/images/sym-img-2-small.jpg" alt="Home Slider 01" />
                </div>
                </div>
            </div>
        </div>
        <!-- Navigation arrows -->
        <!-- <div class="swiper-button-next"></div>
        <div class="swiper-button-prev"></div> -->
    </div>
 </div>
 
 <!-- Single Shared Pagination -->

 <div class="shared-pagination-wrapper">
 <div class="shared-pagination"></div>
 </div>
 </section>