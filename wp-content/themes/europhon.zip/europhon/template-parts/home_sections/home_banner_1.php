


<section class="waper_page_slider">
    <div class="main_slider">
        <div class="mydiv">
            <div class="banner_sec banner_sec_1 d_flex">
                <video autoplay loop muted playsinline class="banner_background_video" style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; object-fit: cover; z-index: -1;">
                    <source src="<?php echo get_template_directory_uri(); ?>/images/banner-video.mp4" type="video/mp4">
                </video>
                <div class="bg-overlay"></div>
                <div class="container" style="position: relative; z-index: 1;">
                    <div class="banner_content text_center">
                        <div class="tag_line color_white f_24" data-aos="fade-up" data-aos-duration="1200"
                            data-aos-once="true">Design. Engineering. Acoustic Excellence.</div>
                        <h1 class="f_80 color_white" data-aos="fade-up" data-aos-duration="1400" data-aos-once="true">
                            VOICE OF THE MAKER</h1>
                        <div data-aos="fade-up" data-aos-duration="1600" data-aos-once="true">
                            <a href="/contact-us" class="btn_style">Enquire Now</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="mydiv">
            <div class="banner_sec d_flex"
                style="background-image: url('<?php echo get_template_directory_uri(); ?>/images/home_bg_2.webp');">
                <div class="container">
                    <div class="banner_content text_center">
                        <h2 class="f_80 color_white" data-aos="fade-up" data-aos-duration="1200" data-aos-once="true">
                            Commercial Space</h2>
                        <p class="f_32 mt_20 color_white" data-aos="fade-up" data-aos-duration="1200"
                            data-aos-once="true">Whether you're designing a workspace, a cultural venue, or a healthcare
                            facility, our experts are here to help you achieve the perfect acoustic solution.</p>
                        <div data-aos="fade-up" data-aos-duration="1200" data-aos-once="true">
                            <a href="/services" class="btn_style">Discover Now</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="mydiv">
            <div class="banner_sec d_flex"
                style="background-image: url('<?php echo get_template_directory_uri(); ?>/images/home_bg_3.webp');">
                <div class="container">
                    <div class="banner_content text_center">
                        <h2 class="f_80 color_white" data-aos="fade-up" data-aos-duration="1200" data-aos-once="true">
                            The Symfony of products</h2>
                        <p class="f_32 mt_20 color_white" data-aos="fade-up" data-aos-duration="1200"
                            data-aos-once="true">Advanced acoustic ceiling solutions</p>
                        <div data-aos="fade-up" data-aos-duration="1200" data-aos-once="true">
                            <a href="/services" class="btn_style">Discover Now</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Dots inside wrapper -->
    <div class="slider-dots show"></div>
</section>

<section class="waper_banner_mobile">
    <div class="banner_sec banner_sec_1 d_flex radial_gradient"
                style="background-image: url('<?php echo get_template_directory_uri(); ?>/images/home_bg_1.webp');">
                <div class="container">
                    <div class="banner_content text_center">
                        <div class="tag_line color_white f_24" data-aos="fade-up" data-aos-duration="1200"
                            data-aos-once="true">Design. Engineering. Acoustic Excellence.</div>
                        <h1 class="f_80 color_white" data-aos="fade-up" data-aos-duration="1400" data-aos-once="true">
                            VOICE OF THE MAKER</h1>
                        <div data-aos="fade-up" data-aos-duration="1600" data-aos-once="true">
                            <a href="/contact-us" class="btn_style">Enquire Now</a>
                        </div>
                    </div>
                </div>
            </div>


  <div class="banner_sec d_flex"
                style="background-image: url('<?php echo get_template_directory_uri(); ?>/images/home_bg_2.webp');">
                <div class="container">
                    <div class="banner_content text_center">
                        <h2 class="f_80 color_white" data-aos="fade-up" data-aos-duration="1200" data-aos-once="true">
                            Commercial Space</h2>
                        <p class="f_32 mt_20 color_white" data-aos="fade-up" data-aos-duration="1200"
                            data-aos-once="true">Whether you’re designing a workspace, a cultural venue, or a healthcare
                            facility, our experts are here to help you achieve the perfect acoustic solution.</p>
                        <div data-aos="fade-up" data-aos-duration="1200" data-aos-once="true">
                            <a href="" class="btn_style">Discover Now</a>
                        </div>
                    </div>
                </div>
            </div>
   <div class="banner_sec d_flex"
                style="background-image: url('<?php echo get_template_directory_uri(); ?>/images/home_bg_3.webp');">
                <div class="container">
                    <div class="banner_content text_center">
                        <h2 class="f_80 color_white" data-aos="fade-up" data-aos-duration="1200" data-aos-once="true">
                            The Symfony of products</h2>
                        <p class="f_32 mt_20 color_white" data-aos="fade-up" data-aos-duration="1200"
                            data-aos-once="true">Advanced acoustic ceiling solutions</p>
                        <div data-aos="fade-up" data-aos-duration="1200" data-aos-once="true">
                            <a href="" class="btn_style">Discover Now</a>
                        </div>
                    </div>
                </div>
            </div>
</section>
