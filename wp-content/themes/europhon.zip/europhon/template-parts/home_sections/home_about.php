<section class="who_we_are">
    <div class="container">
        <div class="text_center home_about">
            <h2 class="f_56" data-aos="fade-up" data-aos-duration="1200" data-aos-once="true">Who We Are</h2>
            <p class="f_20 lh_180 mt_50" data-aos="fade-up" data-aos-duration="1200" data-aos-once="true">Our acoustics systems offered consist of a unique combination of highly effective sound absorption with flexibility in design. They aim to reduce and control the reverberation time. When controlling the reverberation time of sound waves, the results will create a pleasant acoustic room climate.</p>
			<div da ta-aos="fade-up" data-aos-duration="1200" data-aos-once="true">
            <a href="/about-us" class="highlight_text mt_50">Learn More About Us</a>
			</div>
        </div>
    </div>
</section>