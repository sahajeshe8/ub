
<section class="service_difference">
    <img src="<?php echo get_template_directory_uri(); ?>/images/difference_bg.webp" alt="img">

    <div class="container">
      <h2 class="color_white f_56 text_center" data-aos="fade-up" data-aos-duration="1200" data-aos-once="true">Where Our Consulting Makes a Difference</h2>
    </div>

  </section>