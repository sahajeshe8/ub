<section class="core_value pb_150 pt_150">
    <div class="container">
        <div class="text_center">
            <h2 class="f_56" data-aos="fade-up" data-aos-duration="1200" data-aos-once="true">How We Work With You</h2>
        </div>

        <div class="core_value_grid mt_80">
            <div class="core_grid_box" data-aos="fade-up" data-aos-duration="1200" data-aos-once="true">
                <div class="core_grid_img">
                    <img src="<?php echo get_template_directory_uri(); ?>/images/service_img_1.png" alt="img">
                </div>
                <div class="value_title">
                    Assessment & Analysis
                </div>
                <p class="f_17">On-site studies, acoustic modeling, and diagnostics</p>
            </div>
 <div class="core_grid_box" data-aos="fade-up" data-aos-duration="1200" data-aos-once="true">
                <div class="core_grid_img">
                    <img src="<?php echo get_template_directory_uri(); ?>/images/service_img_2.png" alt="img">
                </div>
                <div class="value_title">
                    Design Integration
                </div>
                <p class="f_17">Collaboration with architects and designers for seamless solutions.</p>
            </div>
             <div class="core_grid_box" data-aos="fade-up" data-aos-duration="1200" data-aos-once="true">
                <div class="core_grid_img">
                    <img src="<?php echo get_template_directory_uri(); ?>/images/service_img_3.png" alt="img">
                </div>
                <div class="value_title">
                    Custom Recommendations
                </div>
                <p class="f_17">Product selection, tailored materials, and finishes.</p>
            </div>
             <div class="core_grid_box" data-aos="fade-up" data-aos-duration="1200" data-aos-once="true">
                <div class="core_grid_img">
                    <img src="<?php echo get_template_directory_uri(); ?>/images/service_img_4.png" alt="img">
                </div>
                <div class="value_title">
                    Implementation Support
                </div>
                <p class="f_17">Guidance through installation and commissioning.</p>
            </div>
        </div>
    </div>
</section>