<section class="who_we_are sm_padding">
    <div class="container">
        <div class="text_center service_about">
            <h2 class="f_56" data-aos="fade-up" data-aos-duration="1200" data-aos-once="true">Why Acoustic Consulting Matters</h2>
            <p class="f_20 mt_40" data-aos="fade-up" data-aos-duration="1200" data-aos-once="true">Good acoustics are not just about reducing noise—they shape the way people feel, work, and interact in a space. Whether it’s a concert hall, a hospital ward, or an open-plan office, our consulting team ensures that sound is managed with precision, enhancing clarity, comfort, and well-being.</p>
        </div>
    </div>
</section>