<section class="who_we_are sm_padding">
    <div class="container">
        <div class="text_center service_about">
            <h2 class="f_56" data-aos="fade-up" data-aos-duration="1200" data-aos-once="true">THE SYMPHONY OF PRODUCTS</h2>
            <p class="f_20 mt_40" data-aos="fade-up" data-aos-duration="1200" data-aos-once="true">Europhon Acoustics provides a comprehensive portfolio of acoustic solutions designed to meet the most demanding architectural and design
requirements. Each product family carries the Symfony® brand, representing precision engineering, acoustic performance, and refined design.</p>
        </div>
    </div>
</section>