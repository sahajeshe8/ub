<section class="sub_page_banner">
    <video autoplay loop muted playsinline class="banner_background_video" style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; object-fit: cover; z-index: -1;">
        <source src="<?php echo get_template_directory_uri(); ?>/images/banner-video.mp4" type="video/mp4">
    </video>
    <div class="bg-overlay"></div>
    <div class="container" style="position: relative; z-index: 1;">
      <div class="banner_nav_wraper">
<!--         <div class="banner_bread_crumb">
            <div class="banner_bc_title" data-aos="fade-right" data-aos-duration="1400" data-aos-once="true">About Us</div>
        </div> -->
         <div class="banner_content text_center">
        <h1 class="f_56 color_white" data-aos="fade-up" data-aos-duration="1400" data-aos-once="true">Products</h1>
       </div>
      </div>
    </div>
</section>