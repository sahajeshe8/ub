<section class="divider-main">
    <div class="dividers-banner"
        style="background-image: url('<?php echo get_template_directory_uri(); ?>/images/product_glass_bg_1.webp');">
        <div class="container">
            <div class="glass-card" data-aos="fade-up" data-aos-duration="1200" data-aos-once="true">
                <div class="card-header">
                    <h2>Symphony Glass</h2>
                    <span class="slide-count">1/5</span>
                </div>

              <div class="card_body">
                <p class="description">
                    High-performance single and double-glazed partition systems that combine transparency with acoustic
                    control. Ideal for offices, executive suites, and commercial environments, Symphony Glass delivers
                    openness without compromising privacy.
                </p>

                <a href="/products-symphony" class="discover-link">DISCOVER NOW</a>

                <div class="options">
                    <span>Single Glaze</span>
                    <span>Single Glaze with door</span>
                    <span>Double Glaze</span>
                    <span>Double Glaze with door</span>
                </div>
                </div>
            </div>
        </div>
    </div>
    <div class="dividers-banner"
        style="background-image: url('<?php echo get_template_directory_uri(); ?>/images/product_glass_bg_2.webp');">
        <div class="container">
            <div class="glass-card" data-aos="fade-up" data-aos-duration="1200" data-aos-once="true">
                <div class="card-header">
                    <h2>Symfony Fabric</h2>
                    <span class="slide-count">2/5</span>
                </div>

                <div class="card_body">
                <p class="description">
                A versatile range of fabric acoustic panels, acoustic curtains, and acoustic curtain dividers is available in a variety of textures and colors. These acoustic Products enhance sound absorption while adding aesthetic warmth to interiors, making them suitable for workspaces, hospitality, and residential projects.
                </p>

                <a href="" class="discover-link">DISCOVER NOW</a>

                 <div class="options">
                    <span>Acoustic Fabric Panel</span>
                    <span>Acoustic Curtain</span>
                    <span>Acoustic Curtain Divider</span>
                 </div>
                </div>
            </div>
        </div>
    </div>
    <div class="dividers-banner"
        style="background-image: url('<?php echo get_template_directory_uri(); ?>/images/product_glass_bg_3.webp');">
        <div class="container">
            <div class="glass-card" data-aos="fade-up" data-aos-duration="1200" data-aos-once="true">
                <div class="card-header">
                    <h2>Symfony Wall</h2>
                    <span class="slide-count">3/5</span>
                </div>

                <div class="card_body">
                <p class="description">
                Movable and demountable wall systems that provide flexible space division with excellent acoustic insulation. Engineered for adaptability, Symfony® Wall is perfect for multipurpose halls, offices, and educational institutions.

                </p>

                <a href="#" class="discover-link">DISCOVER NOW</a>

                <div class="options">
                    <span>Movable Wall Partition</span>
                    <span>Soundwall</span>
                    <span>Polysound</span>
                 </div>
                </div>
            </div>
        </div>
    </div>
    <div class="dividers-banner"
        style="background-image: url('<?php echo get_template_directory_uri(); ?>/images/product_glass_bg_4.webp');">
        <div class="container">
            <div class="glass-card" data-aos="fade-up" data-aos-duration="1200" data-aos-once="true">
                <div class="card-header">
                    <h2>Symfony Ceiling</h2>
                    <span class="slide-count">4/5</span>
                </div>

                <div class="card_body">
                <p class="description">
                Advanced acoustic ceiling solutions that reduce noise levels while maintaining visual elegance. Designed for large public areas, corporate offices, and cultural spaces, Symfony® Ceiling enhances clarity and comfort in demanding acoustic environments.
                </p>

                <a href="/products-symphony" class="discover-link">DISCOVER NOW</a>

                <div class="options">
                    <span>Melo</span>
                    <span>Acoustical Spray</span>
                    <span>Symphony Tile - Clip in</span>
                    <span>Symphony Tile - Lay in</span>
                    <span>Symphony Tile - Linear Baffle</span>
                   
                </div>
                </div>
            </div>
        </div>
    </div>

    <div class="dividers-banner"
        style="background-image: url('<?php echo get_template_directory_uri(); ?>/images/product_glass_bg_5.webp');">
        <div class="container">
            <div class="glass-card" data-aos="fade-up" data-aos-duration="1200" data-aos-once="true">
                <div class="card-header">
                    <h2>Symphony Glass</h2>
                    <span class="slide-count">5/5</span>
                </div>
                <div class="card_body">
                <p class="description">
                   Acoustic baffles and suspended wave systems that transform ceilings into sculptural sound absorbers. Symfony® Wave combines striking design with high-performance acoustics, ideal for modern workplaces, auditoriums, and creative environments.

                </p>

                <a href="/products-symphony" class="discover-link">DISCOVER NOW</a>

              <div class="options">
                    <span>Baffle</span>
                    <span>Pet Panels</span>
                   
                </div>
                </div>
            </div>
        </div>
    </div>

</section>