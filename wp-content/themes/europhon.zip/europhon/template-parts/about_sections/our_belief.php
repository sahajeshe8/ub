<section class="belief_sec pb_150 pt_150">
    <div class="container">
        <div class="text_center">
            <h2 class="f_56 color_white" data-aos="fade-up" data-aos-duration="1200" data-aos-once="true">Our Belief</h2>
			<p class="color_white mt_20" data-aos="fade-up" data-aos-duration="1200" data-aos-once="true">
			Silence is not a void. It's a presence.
<br>A state where creativity thrives, focus sharpens, and design breathes.
<br>We transform silence into design - because every great idea deserves to be heard clearly.
			</p>
		</div>

        <div class="belief_grid mt_80">
            <div class="belief_box" data-aos="fade-up" data-aos-duration="1200" data-aos-once="true">
                <div class="belief_grid_img">
                    <img src="<?php echo get_template_directory_uri(); ?>/images/belief_1.png" alt="img">
                </div>
                <div class="value_title color_white">
                    Mission
                </div>
                <p class="f_18 color_white">Our mission is simple: to transform silence into design. Europhon Acoustics® creates systems that do more than manage sound, they shape experiences. We aim to empower architects and designers with solutions that bring clarity, focus, and elegance to every space, blending acoustic science with modern aesthetics.</p>
            </div>
 <div class="belief_box" data-aos="fade-up" data-aos-duration="1200" data-aos-once="true">
                <div class="belief_grid_img">
                    <img src="<?php echo get_template_directory_uri(); ?>/images/belief_2.png" alt="img">
                </div>
                <div class="value_title color_white">
                    Vision
                </div>
                <p class="f_18 color_white">We envision a future where acoustic comfort is an integral part of architecture, not an afterthought. Europhon Acoustics®  strives to set global standards for innovation and design in the acoustic industry, creating products that inspire creativity, foster wellbeing, and support the evolving needs of modern environments.</p>
            </div>
        </div>
    </div>
</section>