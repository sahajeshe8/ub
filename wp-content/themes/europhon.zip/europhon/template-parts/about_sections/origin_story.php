

<section class="original_story">
    <video autoplay loop muted playsinline class="banner_background_video">
        <source src="<?php echo get_template_directory_uri(); ?>/images/banner-video.mp4" type="video/mp4">
    </video>
    <div class="bg-overlay"></div>
    <div class="container">
        <div class="original_story_row d_flex">
            <div class="original_story_col">
                <div class="original_col_l">
                    <h2 class="f_56 color_white" data-aos="fade-right" data-aos-duration="1200" data-aos-once="true">Our Origin Story</h2>
                </div>
            </div>
            <div class="original_story_col">
                <div class="original_col_r" data-aos="fade-up" data-aos-duration="1200" data-aos-once="true">
                    <p class="f_18 color_white">Born from the legacy of Euro Systems, Europhon Acoustics® was created to shape how modern
                        architecture feels not just how it looks.</p>
                    <p class="f_18 color_white">What began as a pursuit of precision and innovation in design evolved into an obsession with the
                        art of sound.</p>

                    <p class="f_18 color_white">Today, we're redefining how silence enhances every environment transforming comfort, focus, and
                        emotion.</p>
                </div>
            </div>
        </div>
    </div>
</section>