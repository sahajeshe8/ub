<section class="about_beginning">
    <div class="container">
        <div class="text_center">
            <h2 class="f_36" data-aos="fade-up" data-aos-duration="1200" data-aos-once="true">Silence is not the absence of sound - It’s the beginning of design.</h2>
            <p class="f_20 mt_30" data-aos="fade-up" data-aos-duration="1200" data-aos-once="true">At <span class="f_20 bold_style">Europhon Acoustics®</span>, We design the language of silence shaping environments where sound finds its balance, and design finds its calm.</p>
        </div>
    </div>
</section>