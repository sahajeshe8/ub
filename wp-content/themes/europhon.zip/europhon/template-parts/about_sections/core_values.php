

<section class="core_value pb_150 pt_150">
    <div class="container">
        <div class="text_center">
            <h2 class="f_56" data-aos="fade-up" data-aos-duration="1200" data-aos-once="true">Core Values</h2>
        </div>

        <div class="core_value_grid mt_80">
            <div class="core_grid_box" data-aos="fade-up" data-aos-duration="1200" data-aos-once="true">
                <div class="core_grid_img">
                    <img src="<?php echo get_template_directory_uri(); ?>/images/core_img_1.png" alt="img">
                </div>
                <div class="value_title">
                    Innovation
                </div>
                <p class="f_18">Continuously advancing acoustic technology and design solutions.</p>
            </div>
 <div class="core_grid_box" data-aos="fade-up" data-aos-duration="1200" data-aos-once="true">
                <div class="core_grid_img">
                    <img src="<?php echo get_template_directory_uri(); ?>/images/core_img_2.png" alt="img">
                </div>
                <div class="value_title">
                    Precision
                </div>
                <p class="f_18">Engineering every system with attention to technical detail and seamless execution.</p>
            </div>
             <div class="core_grid_box" data-aos="fade-up" data-aos-duration="1200" data-aos-once="true">
                <div class="core_grid_img">
                    <img src="<?php echo get_template_directory_uri(); ?>/images/core_img_3.png" alt="img">
                </div>
                <div class="value_title">
                    Sustainability
                </div>
                <p class="f_18">Creating solutions that respect the environment and support responsible design.</p>
            </div>
             <div class="core_grid_box" data-aos="fade-up" data-aos-duration="1200" data-aos-once="true">
                <div class="core_grid_img">
                    <img src="<?php echo get_template_directory_uri(); ?>/images/core_img_4.png" alt="img">
                </div>
                <div class="value_title">
                    Collaboration
                </div>
                <p class="f_18">Working hand-in-hand with architects, designers, and consultants to bring ideas to life.</p>
            </div>
        </div>
    </div>
</section>