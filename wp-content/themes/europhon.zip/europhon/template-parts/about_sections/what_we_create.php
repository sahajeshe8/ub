<section class="about_beginning pb_150 pt_150">
    <div class="container">
        <div class="text_center">
            <h2 class="f_56" data-aos="fade-up" data-aos-duration="1200" data-aos-once="true">What We Create</h2>
            <p class="f_20 mt_20" data-aos="fade-up" data-aos-duration="1200" data-aos-once="true">THE SYMPHONY OF PRODUCTS</p>
        </div>
    </div>
</section>