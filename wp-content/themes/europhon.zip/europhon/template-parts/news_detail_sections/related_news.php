

<section class="related_news pt_150 pb_150">
    <div class="container">
  <div class="top_h">
        <h2 class="f_56 color_white" data-aos="fade-right" data-aos-duration="1200" data-aos-once="true">Our Belief</h2>
  </div>

        <div class="news_listing_grid mt_80">
            <a href="" class="news_grid_box" data-aos="fade-up" data-aos-duration="1200" data-aos-once="true">
                <div class="news_gird_img">
                    <img src="<?php echo get_template_directory_uri(); ?>/images/news_img_8.png" alt="img">
                </div>
                <div class="news_date color_white">Jan 24, 2025</div>
                <div class="news_title color_white">
                    3D Acoustic Ceiling Tiles
                </div>
                <p class="f_18 color_white">The Symfony Double Glaze Glass Partition with Door is a precision-engineered
                    architectural solution that elevates spatial design</p>
            </a>

            <a href="" class="news_grid_box" data-aos="fade-up" data-aos-duration="1200" data-aos-once="true">
                <div class="news_gird_img">
                    <img src="<?php echo get_template_directory_uri(); ?>/images/news_img_9.png" alt="img">
                </div>
                <div class="news_date color_white">Jan 24, 2025</div>
                <div class="news_title color_white">
                    3D Acoustic Ceiling Tiles
                </div>
                <p class="f_18 color_white">The Symfony Double Glaze Glass Partition with Door is a precision-engineered
                    architectural solution that elevates spatial design</p>
            </a>

            <a href="" class="news_grid_box" data-aos="fade-up" data-aos-duration="1200" data-aos-once="true">
                <div class="news_gird_img">
                    <img src="<?php echo get_template_directory_uri(); ?>/images/news_img_10.png" alt="img">
                </div>
                <div class="news_date color_white">Jan 24, 2025</div>
                <div class="news_title color_white">
                    3D Acoustic Ceiling Tiles
                </div>
                <p class="f_18 color_white">The Symfony Double Glaze Glass Partition with Door is a precision-engineered
                    architectural solution that elevates spatial design</p>
            </a>
        </div>
    </div>
</section>