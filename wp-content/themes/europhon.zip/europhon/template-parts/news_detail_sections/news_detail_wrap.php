<section class="news_detail_content pt_150 pb_150">
  <div class="container news_d_container">
    <div class="news_detail_header" data-aos="fade-up" data-aos-duration="1400" data-aos-once="true">
      <h1 class="text_center f_56">3D Acoustic Ceiling Tiles</h1>

      <div class="news_dates_flex d_flex">
        <div class="news_date_l">
          <p>January 11, 2025</p>
          <span>|</span>
          <p>5 minute read</p>
        </div>

        <div class="news_social">
          <a href="" target="_blank">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 18 18">
              <path
                d="M1.38524 16.125C1.82478 16.5652 2.34695 16.9141 2.92177 17.1519C3.49659 17.3896 4.11272 17.5114 4.73476 17.5103C5.35693 17.5114 5.9732 17.3896 6.54816 17.1518C7.12313 16.9141 7.64548 16.5652 8.08522 16.125L10.7648 13.4444L9.42503 12.1046L6.74541 14.7852C6.21145 15.3168 5.48868 15.6152 4.73523 15.6152C3.98178 15.6152 3.25901 15.3168 2.72505 14.7852C2.19301 14.2515 1.89426 13.5286 1.89426 12.775C1.89426 12.0214 2.19301 11.2985 2.72505 10.7648L5.40561 8.08522L4.0658 6.74541L1.38524 9.42503C0.498171 10.3142 0 11.519 0 12.775C0 14.031 0.498171 15.2358 1.38524 16.125ZM16.125 8.08522C17.0116 7.19576 17.5095 5.9911 17.5095 4.73523C17.5095 3.47936 17.0116 2.2747 16.125 1.38524C15.2358 0.498171 14.031 0 12.775 0C11.519 0 10.3142 0.498171 9.42503 1.38524L6.74541 4.0658L8.08522 5.40561L10.7648 2.72505C11.2988 2.19348 12.0216 1.89504 12.775 1.89504C13.5285 1.89504 14.2512 2.19348 14.7852 2.72505C15.3172 3.25876 15.616 3.98163 15.616 4.73523C15.616 5.48883 15.3172 6.2117 14.7852 6.74541L12.1046 9.42503L13.4444 10.7648L16.125 8.08522ZM5.40465 13.4455L4.0639 12.1057L12.1056 4.06494L13.4454 5.40569L5.40465 13.4455Z" />
              <path
                d="M1.38524 16.125C1.82478 16.5652 2.34695 16.9141 2.92177 17.1519C3.49659 17.3896 4.11272 17.5114 4.73476 17.5103C5.35693 17.5114 5.9732 17.3896 6.54816 17.1518C7.12313 16.9141 7.64548 16.5652 8.08522 16.125L10.7648 13.4444L9.42503 12.1046L6.74541 14.7852C6.21145 15.3168 5.48868 15.6152 4.73523 15.6152C3.98178 15.6152 3.25901 15.3168 2.72505 14.7852C2.19301 14.2515 1.89426 13.5286 1.89426 12.775C1.89426 12.0214 2.19301 11.2985 2.72505 10.7648L5.40561 8.08522L4.0658 6.74541L1.38524 9.42503C0.498171 10.3142 0 11.519 0 12.775C0 14.031 0.498171 15.2358 1.38524 16.125ZM16.125 8.08522C17.0116 7.19576 17.5095 5.9911 17.5095 4.73523C17.5095 3.47936 17.0116 2.2747 16.125 1.38524C15.2358 0.498171 14.031 0 12.775 0C11.519 0 10.3142 0.498171 9.42503 1.38524L6.74541 4.0658L8.08522 5.40561L10.7648 2.72505C11.2988 2.19348 12.0216 1.89504 12.775 1.89504C13.5285 1.89504 14.2512 2.19348 14.7852 2.72505C15.3172 3.25876 15.616 3.98163 15.616 4.73523C15.616 5.48883 15.3172 6.2117 14.7852 6.74541L12.1046 9.42503L13.4444 10.7648L16.125 8.08522ZM5.40465 13.4455L4.0639 12.1057L12.1056 4.06494L13.4454 5.40569L5.40465 13.4455Z" />
            </svg>
          </a>

          <a href="" target="_blank">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 14 13">
              <path
                d="M13.6646 8.15434V12.5383C13.6646 12.646 13.5618 12.7383 13.4417 12.7383H10.9214C10.8014 12.7383 10.6985 12.646 10.6985 12.5383V8.46199C10.6985 7.38523 10.2699 6.64688 9.18977 6.64688C8.3668 6.64688 7.88674 7.13911 7.66386 7.61596C7.57813 7.78517 7.56098 8.03129 7.56098 8.26202V12.5383C7.56098 12.646 7.45811 12.7383 7.3381 12.7383H4.83492C4.7149 12.7383 4.61203 12.646 4.61203 12.5383C4.61203 11.4462 4.64632 6.17002 4.61203 4.93944C4.61203 4.83176 4.7149 4.73947 4.83492 4.73947H7.35524C7.47526 4.73947 7.57813 4.83176 7.57813 4.93944V5.87776C7.57813 5.89314 7.56098 5.89314 7.56098 5.90852H7.57813V5.87776C7.97247 5.33938 8.67542 4.55488 10.2528 4.55488C12.2073 4.55488 13.6646 5.70855 13.6646 8.15434ZM0.222886 12.7537H2.74321C2.86323 12.7537 2.9661 12.6614 2.9661 12.5537V4.93944C2.9661 4.83176 2.86323 4.73947 2.74321 4.73947H0.222886C0.10287 4.73947 0 4.83176 0 4.93944V12.5537C0.0171451 12.6614 0.10287 12.7537 0.222886 12.7537Z" />
              <path
                d="M1.82195 3.6439C2.82819 3.6439 3.6439 2.82819 3.6439 1.82195C3.6439 0.815716 2.82819 0 1.82195 0C0.815715 0 0 0.815716 0 1.82195C0 2.82819 0.815715 3.6439 1.82195 3.6439Z" />
            </svg>
          </a>

          <a href="" target="_blank">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 15 15">
              <path
                d="M11.0393 2.48996C10.8685 2.48996 10.7016 2.54061 10.5595 2.6355C10.4175 2.73039 10.3068 2.86526 10.2415 3.02306C10.1761 3.18086 10.159 3.35449 10.1923 3.52201C10.2257 3.68952 10.3079 3.8434 10.4287 3.96417C10.5494 4.08494 10.7033 4.16719 10.8708 4.20051C11.0384 4.23383 11.212 4.21673 11.3698 4.15137C11.5276 4.08601 11.6625 3.97532 11.7573 3.83331C11.8522 3.69129 11.9029 3.52433 11.9029 3.35353C11.9029 3.1245 11.8119 2.90485 11.6499 2.7429C11.488 2.58095 11.2683 2.48996 11.0393 2.48996ZM14.3497 4.2315C14.3357 3.63441 14.2238 3.04366 14.0186 2.48277C13.8356 2.00286 13.5509 1.5683 13.1838 1.209C12.8275 0.840129 12.3919 0.55713 11.9101 0.38141C11.3507 0.169951 10.7593 0.0555636 10.1613 0.0431785C9.39853 -4.02131e-08 9.15385 0 7.19642 0C5.239 0 4.99432 -4.02131e-08 4.2315 0.0431785C3.63358 0.0555636 3.04217 0.169951 2.48277 0.38141C2.00181 0.558909 1.56661 0.841665 1.209 1.209C0.840129 1.56535 0.55713 2.00092 0.38141 2.48277C0.169951 3.04217 0.0555636 3.63358 0.0431785 4.2315C-4.02131e-08 4.99432 0 5.239 0 7.19642C0 9.15385 -4.02131e-08 9.39853 0.0431785 10.1613C0.0555636 10.7593 0.169951 11.3507 0.38141 11.9101C0.55713 12.3919 0.840129 12.8275 1.209 13.1838C1.56661 13.5512 2.00181 13.8339 2.48277 14.0114C3.04217 14.2229 3.63358 14.3373 4.2315 14.3497C4.99432 14.3928 5.239 14.3928 7.19642 14.3928C9.15385 14.3928 9.39853 14.3928 10.1613 14.3497C10.7593 14.3373 11.3507 14.2229 11.9101 14.0114C12.3919 13.8357 12.8275 13.5527 13.1838 13.1838C13.5525 12.8259 13.8375 12.3909 14.0186 11.9101C14.2238 11.3492 14.3357 10.7584 14.3497 10.1613C14.3497 9.39853 14.3928 9.15385 14.3928 7.19642C14.3928 5.239 14.3928 4.99432 14.3497 4.2315ZM13.0543 10.075C13.0491 10.5318 12.9663 10.9844 12.8096 11.4135C12.6947 11.7267 12.5102 12.0097 12.2699 12.2411C12.0365 12.479 11.7541 12.6631 11.4423 12.7808C11.0132 12.9376 10.5606 13.0203 10.1038 13.0255C9.38414 13.0615 9.11787 13.0687 7.22521 13.0687C5.33255 13.0687 5.06628 13.0687 4.34664 13.0255C3.87232 13.0344 3.40002 12.9614 2.95053 12.8096C2.65244 12.6859 2.38299 12.5022 2.15893 12.2699C1.92007 12.0387 1.73782 11.7555 1.62639 11.4423C1.4507 11.007 1.35325 10.5442 1.33853 10.075C1.33853 9.35535 1.29536 9.08908 1.29536 7.19642C1.29536 5.30376 1.29536 5.0375 1.33853 4.31785C1.34176 3.85085 1.42701 3.38804 1.59041 2.95053C1.7171 2.64678 1.91156 2.37601 2.15893 2.15893C2.37756 1.91149 2.64777 1.71498 2.95053 1.58321C3.38919 1.42492 3.85152 1.34219 4.31785 1.33853C5.0375 1.33853 5.30376 1.29536 7.19642 1.29536C9.08908 1.29536 9.35535 1.29536 10.075 1.33853C10.5318 1.34377 10.9844 1.42651 11.4135 1.58321C11.7406 1.70458 12.0341 1.9019 12.2699 2.15893C12.5057 2.37999 12.69 2.65025 12.8096 2.95053C12.9696 3.38875 13.0524 3.85137 13.0543 4.31785C13.0903 5.0375 13.0975 5.30376 13.0975 7.19642C13.0975 9.08908 13.0903 9.35535 13.0543 10.075ZM7.19642 3.50466C6.46657 3.50608 5.75351 3.72381 5.14735 4.13033C4.54119 4.53685 4.06913 5.11392 3.79081 5.78863C3.51249 6.46333 3.44041 7.20539 3.58367 7.92105C3.72693 8.63671 4.0791 9.29385 4.59569 9.80943C5.11228 10.325 5.7701 10.6759 6.48603 10.8178C7.20197 10.9596 7.94389 10.8861 8.61805 10.6065C9.29222 10.3268 9.86837 9.85366 10.2737 9.24671C10.679 8.63976 10.8954 7.92628 10.8954 7.19642C10.8963 6.71074 10.8013 6.22966 10.6156 5.78085C10.43 5.33205 10.1574 4.92438 9.81367 4.58128C9.4699 4.23818 9.0617 3.96644 8.61253 3.78167C8.16337 3.5969 7.6821 3.50276 7.19642 3.50466ZM7.19642 9.59283C6.72246 9.59283 6.25914 9.45228 5.86505 9.18896C5.47096 8.92564 5.16381 8.55138 4.98243 8.11349C4.80105 7.6756 4.75359 7.19376 4.84606 6.72891C4.93853 6.26405 5.16676 5.83705 5.50191 5.50191C5.83705 5.16676 6.26405 4.93853 6.72891 4.84606C7.19376 4.75359 7.6756 4.80105 8.11349 4.98243C8.55138 5.16381 8.92564 5.47096 9.18896 5.86505C9.45228 6.25914 9.59283 6.72246 9.59283 7.19642C9.59283 7.51112 9.53085 7.82274 9.41042 8.11349C9.28998 8.40423 9.11347 8.66841 8.89094 8.89094C8.66841 9.11347 8.40423 9.28998 8.11349 9.41042C7.82274 9.53085 7.51112 9.59283 7.19642 9.59283Z" />
            </svg>
          </a>

          <a href="" target="_blank">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 12 12">
              <path
                d="M7.13769 5.07862L11.6025 0H10.5443L6.66855 4.40952L3.57149 0H0L4.68262 6.66869L0 11.994H1.05822L5.15177 7.33693L8.42255 11.994H11.994L7.13769 5.07862ZM5.68881 6.72694L5.21438 6.06299L1.43918 0.779613H3.06443L6.11034 5.04349L6.58477 5.70745L10.5452 11.2504H8.91991L5.68881 6.72694Z" />
            </svg>
          </a>

        </div>
      </div>
    </div>


    <div class="news_d_inner">
      <div class="news_d_slider" data-aos="fade-up" data-aos-duration="1400" data-aos-once="true">
        <div class="news_d_slider_box">
          <img src="<?php echo get_template_directory_uri(); ?>/images/nd_slider_img_1.png" alt="img">
        </div>
        <div class="news_d_slider_box">
          <img src="<?php echo get_template_directory_uri(); ?>/images/nd_slider_img_1.png" alt="img">
        </div>
        <div class="news_d_slider_box">
          <img src="<?php echo get_template_directory_uri(); ?>/images/nd_slider_img_1.png" alt="img">
        </div>
        <div class="news_d_slider_box">
          <img src="<?php echo get_template_directory_uri(); ?>/images/nd_slider_img_1.png" alt="img">
        </div>
      </div>

      <p data-aos="fade-up" data-aos-duration="1400" data-aos-once="true">These partitions are engineered with minimal profiles of 25mm, ensuring uninterrupted visual flow while
        maintaining superior sound attenuation. With integrated door systems, frameless joints, and tailored finishes,
        Symfony® Glass is ideal for modern offices, executive suites, and commercial spaces. Where enhanced acoustics
        and privacy can coexist.</p>

      <p data-aos="fade-up" data-aos-duration="1400" data-aos-once="true">Symfony® Acoustic Glass Partitions Systems are designed for transparency without compromise. Symfony® Acoustic
        Glass partitions bring clarity, openness, and acoustic control into one seamless system. Available in single and
        double-glazed options, these partitions are engineered with minimal profiles of 25mm, ensuring uninterrupted
        visual flow while maintaining superior sound attenuation. With integrated door systems, frameless joints, and
        tailored finishes, Symfony® Glass is ideal for modern offices, executive suites, and commercial spaces. Where
        enhanced acoustics and privacy can coexist.</p>

      <div class="news_d_center_img mt_80" data-aos="fade-up" data-aos-duration="1400" data-aos-once="true">
        <img src="<?php echo get_template_directory_uri(); ?>/images/nd_center_img.png" alt="img">
      </div>

      <p data-aos="fade-up" data-aos-duration="1400" data-aos-once="true">
        These partitions are engineered with minimal profiles of 25mm, ensuring uninterrupted visual flow while
        maintaining superior sound attenuation. With integrated door systems, frameless joints, and tailored finishes,
        Symfony® Glass is ideal for modern offices, executive suites, and commercial spaces. Where enhanced acoustics
        and privacy can coexist.</p>

      <p data-aos="fade-up" data-aos-duration="1400" data-aos-once="true">Symfony® Acoustic Glass Partitions Systems are designed for transparency without compromise. Symfony® Acoustic
        Glass partitions bring clarity, openness, and acoustic control into one seamless system. Available in single and
        double-glazed options, these partitions are engineered with minimal profiles of 25mm, ensuring uninterrupted
        visual flow while maintaining superior sound attenuation. With integrated door systems, frameless joints, and
        tailored finishes, Symfony® Glass is ideal for modern offices, executive suites, and commercial spaces. Where
        enhanced acoustics and privacy can coexist.
      </p>

      <p data-aos="fade-up" data-aos-duration="1400" data-aos-once="true">Symfony® Acoustic Glass Partitions Systems are designed for transparency without compromise. Symfony® Acoustic
        Glass partitions bring clarity, openness, and acoustic control into one seamless system. Available in single and
        double-glazed options, these partitions are engineered with minimal profiles of 25mm, ensuring uninterrupted
        visual flow while maintaining superior sound attenuation. With integrated door systems, frameless joints, and
        tailored finishes, Symfony® Glass is ideal for modern offices, executive suites, and commercial spaces. Where
        enhanced acoustics and privacy can coexist.</p>

      <p data-aos="fade-up" data-aos-duration="1400" data-aos-once="true">These partitions are engineered with minimal profiles of 25mm, ensuring uninterrupted visual flow while
        maintaining superior sound attenuation. With integrated door systems, frameless joints, and tailored finishes,
        Symfony® Glass is ideal for modern offices, executive suites, and commercial spaces. Where enhanced acoustics
        and privacy can coexist.
      </p>

    </div>
  </div>
</section>