 <section class="policy_content pt_150 pb_150">
     <div class="container">
         <div class="policy_box" data-aos="fade-up" data-aos-duration="1200" data-aos-once="true">
             <h2 class="f_55">What is personal information?</h2>
             <p>Jan 24, 2025
                 The Symfony Single Glaze Glass Partition System is a precision-engineered architectural solution that
                 harmoniously blends technical excellence
                 with refined luxury. Featuring high-grade single glazing and minimal aluminum profiles, it delivers
                 effective acoustic attenuation alongside
                 uninterrupted transparency. Every element is meticulously crafted to create light-filled, connected
                 spaces that retain the hush of privacy, ensuring
                 both openness and discretion. Its tailored finishes and flawless detailing make it an ideal choice for
                 offices, executive suites, and modern
                 commercial environments where design sophistication and functional performance must coexist. The
                 Symfony Single Glaze Glass Partition System is a precision-engineered architectural solution that
                 harmoniously blends technical excellence with refined luxury.</p>

             <p>Featuring high-grade single glazing and minimal aluminum profiles, it delivers effective acoustic
                 attenuation alongside uninterrupted transparency. Every element is meticulously crafted to create
                 light-filled, connected spaces that retain the hush of privacy, ensuring both openness and discretion.
                 Its tailored finishes and flawless detailing make it an ideal choice for offices, executive suites, and
                 modern commercial environments where design sophistication and functional performance must coexist.
                 Symfony is more than a partition—it is an architectural statement of precision, elegance, and quiet
                 confidence. Symfony is more than a partition—it is an architectural statement of precision, elegance,
                 and quiet confidence.</p>
         </div>


         <div class="policy_box" data-aos="fade-up" data-aos-duration="1200" data-aos-once="true">
             <h2 class="f_55">Collecting your information</h2>
             <p>Jan 24, 2025
                 The Symfony Single Glaze Glass Partition System is a precision-engineered architectural solution that
                 harmoniously blends technical excellence
                 with refined luxury. Featuring high-grade single glazing and minimal aluminum profiles, it delivers
                 effective acoustic attenuation alongside
                 uninterrupted transparency. Every element is meticulously crafted to create light-filled, connected
                 spaces that retain the hush of privacy, ensuring
                 both openness and discretion. Its tailored finishes and flawless detailing make it an ideal choice for
                 offices, executive suites, and modern
                 commercial environments where design sophistication and functional performance must coexist. The
                 Symfony Single Glaze Glass Partition System is a precision-engineered architectural solution that
                 harmoniously blends technical excellence with refined luxury.

             </p>

             <p>Featuring high-grade single glazing and minimal aluminum profiles, it delivers effective acoustic
                 attenuation alongside uninterrupted transparency. Every element is meticulously crafted to create
                 light-filled, connected spaces that retain the hush of privacy, ensuring both openness and discretion.
                 Its tailored finishes and flawless detailing make it an ideal choice for offices, executive suites, and
                 modern commercial environments where design sophistication and functional performance must coexist.
                 Symfony is more than a partition—it is an architectural statement of precision, elegance, and quiet
                 confidence. Symfony is more than a partition—it is an architectural statement of precision, elegance,
                 and quiet confidence.</p>
         </div>


         <div class="policy_box" data-aos="fade-up" data-aos-duration="1200" data-aos-once="true">
             <h2 class="f_55">Managing Cookies</h2>
             <p>Jan 24, 2025
                 TJan 24, 2025
                 The Symfony Single Glaze Glass Partition System is a precision-engineered architectural solution that
                 harmoniously blends technical excellence
                 with refined luxury. Featuring high-grade single glazing and minimal aluminum profiles, it delivers
                 effective acoustic attenuation alongside
                 uninterrupted transparency. Every element is meticulously crafted to create light-filled, connected
                 spaces that retain the hush of privacy, ensuring
                 both openness and discretion. Its tailored finishes and flawless detailing make it an ideal choice for
                 offices, executive suites, and modern
                 commercial environments where design sophistication and functional performance must coexist. The
                 Symfony Single Glaze Glass Partition System is a precision-engineered architectural solution that
                 harmoniously blends technical excellence with refined luxury.
             </p>

             <p>Featuring high-grade single glazing and minimal aluminum profiles, it delivers effective acoustic
                 attenuation alongside uninterrupted transparency. Every element is meticulously crafted to create
                 light-filled, connected spaces that retain the hush of privacy, ensuring both openness and discretion.
                 Its tailored finishes and flawless detailing make it an ideal choice for offices, executive suites, and
                 modern commercial environments where design sophistication and functional performance must coexist.
                 Symfony is more than a partition—it is an architectural statement of precision, elegance, and quiet
                 confidence. Symfony is more than a partition—it is an architectural statement of precision, elegance,
                 and quiet confidence.</p>
         </div>


         <div class="policy_box" data-aos="fade-up" data-aos-duration="1200" data-aos-once="true">
             <h2 class="f_55">Additional Informations</h2>
             <p>The Symfony Single Glaze Glass Partition System is a precision-engineered architectural solution that
                 harmoniously blends technical excellence
                 with refined luxury. Featuring high-grade single glazing and minimal aluminum profiles, it delivers
                 effective acoustic attenuation alongside
                 uninterrupted transparency. Every element is meticulously crafted to create light-filled, connected
                 spaces that retain the hush of privacy, ensuring
                 both openness and discretion. Its tailored finishes and flawless detailing make it an ideal choice for
                 offices, executive suites, and modern
                 commercial environments where design sophistication and functional performance must coexist. The
                 Symfony Single Glaze Glass Partition System is a precision-engineered architectural solution that
                 harmoniously blends technical excellence with refined luxury.
             </p>

             <p>Featuring high-grade single glazing and minimal aluminum profiles, it delivers effective acoustic
                 attenuation alongside uninterrupted transparency. Every element is meticulously crafted to create
                 light-filled, connected spaces that retain the hush of privacy, ensuring both openness and discretion.
                 Its tailored finishes and flawless detailing make it an ideal choice for offices, executive suites, and
                 modern commercial environments where design sophistication and functional performance must coexist.
                 Symfony is more than a partition—it is an architectural statement of precision, elegance, and quiet
                 confidence. Symfony is more than a partition—it is an architectural statement of precision, elegance,
                 and quiet confidence.</p>
         </div>

     </div>
 </section>