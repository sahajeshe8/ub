 <section class="policy_content pt_150 pb_150">
     <div class="container">
         <div class="policy_box" data-aos="fade-up" data-aos-duration="1200" data-aos-once="true">
             <h2 class="f_55">Agreement to Terms</h2>
             <p>By accessing or using this website (the “Site”), and by placing an order or otherwise using our
                 services, you agree to comply with and be bound by these Terms & Conditions (“Terms”), including any
                 additional guidelines or future modifications (the “Agreement”). If you do not agree with these Terms,
                 you should not use the Site or make any purchases.</p>
         </div>

         <div class="policy_box" data-aos="fade-up" data-aos-duration="1200" data-aos-once="true">
             <h2 class="f_55">Products, Services & Eligibility</h2>
             <ul>
                 <li>The Site offers products and services including specialty coffee, artisanal chocolate, gelato,
                     café-equipment, and B2B/café-solutions.</li>
                 <li>By using the Site or placing an order, you represent that you are at least 18 years old (or the
                     legal age required in your jurisdiction) and are capable of forming a binding contract
                 </li>
                 <li>If you access the Site on behalf of a business or other entity, you warrant that you have full
                     authority to bind that entity to these Terms.</li>
             </ul>
         </div>


         <div class="policy_box" data-aos="fade-up" data-aos-duration="1200" data-aos-once="true">
             <h2 class="f_55">Orders, Payment & Pricing</h2>
             <ul>
                 <li>Prices displayed on the Site are in the applicable currency and exclude (or include — depending on
                     your policy) taxes and shipping charges, which are added at checkout.</li>
                 <li>Payment must be completed at the time of purchase via the available payment methods. We accept
                     payments using local and international payment gateways, as available.</li>
                 <li>We reserve the right to refuse or cancel any order at our discretion — for example, if the product
                     is out of stock or payment fails.</li>
                 <li>Once an order is placed and payment is processed, we will send a confirmation email/message.</li>
             </ul>
         </div>


         <div class="policy_box" data-aos="fade-up" data-aos-duration="1200" data-aos-once="true">
             <h2 class="f_55">Use of Website & Acceptable Conduct</h2>
             <p>You agree not to:</p>
             <ul>
                 <li>Use the Site for any unlawful purpose, or violate laws in your jurisdiction.</li>
                 <li>Submit false or misleading information during registration or order.</li>
                 <li>Use bots, automated scripts, or other means to interfere with the Site’s functionality or gain
                     unauthorized access.</li>
                 <li>Upload or distribute content that infringes copyright, is defamatory, obscene, or otherwise
                     objectionable.</li>
                 <li>Abuse, harass, or harm other users, or attempt to compromise Site security.</li>
             </ul>
             <p>We reserve the right to suspend or terminate your access if you violate these rules.</p>
         </div>

         <div class="policy_box" data-aos="fade-up" data-aos-duration="1200" data-aos-once="true">
             <h2 class="f_55">Disclaimers, Warranty & Limitation of Liability</h2>
             <ul>
                 <li>We strive to present accurate product information (descriptions, photos, pricing, availability).
                     However, we do not guarantee that content is error-free or complete.</li>
                 <li>All products are provided “as is” and “as available.” To the maximum extent permitted by applicable
                     law, we disclaim all warranties — express or implied — including fitness for a particular purpose.
                 </li>
                 <li>We shall not be liable for any indirect, incidental, consequential, or punitive damages arising out
                     of your use of the Site or purchase of products, even if we knew such damages were possible.</li>
                 <li>In no event shall our aggregate liability exceed the amount you paid for the product(s) in
                     question.</li>
             </ul>
         </div>

         <div class="policy_box" data-aos="fade-up" data-aos-duration="1200" data-aos-once="true">
             <h2 class="f_55">Changes to Terms & Conditions</h2>
             <p>We may update or modify these Terms at any time. The “Last updated” date at the top will reflect when
                 changes were made. Continued use of the Site after changes constitutes acceptance of the revised Terms.
             </p>
         </div>

     </div>
 </section>