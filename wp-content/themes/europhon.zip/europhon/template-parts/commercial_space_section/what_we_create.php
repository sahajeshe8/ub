<section class="about_beginning pb_150 pt_150">
    <div class="container">
        <div class="text_center">
            <h2 class="f_56" data-aos="fade-up" data-aos-duration="1200" data-aos-once="true">Solutions for All</h2>
            <p class="f_18 mt_20" data-aos="fade-up" data-aos-duration="1200" data-aos-once="true">The Symfony Single Glaze Glass Partition System is a precision-engineered architectural solution that harmoniously blends technical excellence
with refined luxury. Featuring high-grade single glazing and minimal aluminum profiles, it delivers effective acoustic attenuation alongside
uninterrupted transparency. </p>
        </div>
    </div>
</section>