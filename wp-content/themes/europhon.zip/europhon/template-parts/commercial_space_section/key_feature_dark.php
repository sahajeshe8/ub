<section class="key_feature key_feature_dark pt_150 pb_150">
    <div class="container">
        <div class="text_center">
            <h2 class="f_36 text_center" data-aos="fade-up" data-aos-duration="1200" data-aos-once="true">Solutions we
                provide</h2>
        </div>

        <div class="key_feature_grid mt_80">
            <div class="key_feature_box" data-aos="fade-up" data-aos-duration="1200" data-aos-once="true">
                <div class="key_feature_img">
                    <img src="<?php echo get_template_directory_uri(); ?>/images/key_feature_d1.png" alt="img">
                </div>
                <h4>Symfony® Glass</h4>
                <div class="key_feature_title">
                    Slim aluminum profiles with
                    frameless glass-to-glass joints
                </div>
            </div>
            <div class="key_feature_box" data-aos="fade-up" data-aos-duration="1200" data-aos-once="true">
                <div class="key_feature_img">
                    <img src="<?php echo get_template_directory_uri(); ?>/images/key_feature_d2.png" alt="img">
                </div>
                <h4>Symfony® Fabric</h4>
                <div class="key_feature_title">
                    Acoustic performance tailored
                    to project requirements
                </div>
            </div>
            <div class="key_feature_box" data-aos="fade-up" data-aos-duration="1200" data-aos-once="true">
                <div class="key_feature_img">
                    <img src="<?php echo get_template_directory_uri(); ?>/images/key_feature_d3.png" alt="img">
                </div>
                <h4>Symfony® Wall</h4>
                <div class="key_feature_title">
                    Compatible with swing, sliding,
                    and frameless glass doors
                </div>
            </div>
            <div class="key_feature_box" data-aos="fade-up" data-aos-duration="1200" data-aos-once="true">
                <div class="key_feature_img">
                    <img src="<?php echo get_template_directory_uri(); ?>/images/key_feature_d4.png" alt="img">
                </div>
                <h4>Symfony® Ceiling</h4>
                <div class="key_feature_title">
                    Wide range of finishes for frames
                    and accessories
                </div>
            </div>
            <div class="key_feature_box" data-aos="fade-up" data-aos-duration="1200" data-aos-once="true">
                <div class="key_feature_img">
                    <img src="<?php echo get_template_directory_uri(); ?>/images/key_feature_d5.png" alt="img">
                </div>
                <h4>Symfony® Wave</h4>
                <div class="key_feature_title">
                    Light-filled spaces with controlled
                    acoustic comfort
                </div>
            </div>
        </div>
    </div>
</section>