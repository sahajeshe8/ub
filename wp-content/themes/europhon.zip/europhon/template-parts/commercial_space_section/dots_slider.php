

               <div class="double_dots_slider service_dot_slider">
                   <div class="container_fluid">
                       <div class="slider-wrapper" data-aos="fade-up" data-aos-duration="1200" data-aos-once="true">
                           <!-- LEFT IMAGE SLIDER -->
                           <div class="left-slider mb_0">
                               <div><img src="<?php echo get_template_directory_uri(); ?>/images/slider_img_1.png"
                                       alt="Modern Villa Interior 1" /></div>
                               <div><img src="<?php echo get_template_directory_uri(); ?>/images/slider_img_2.png"
                                       alt="Modern Villa Interior 2" /></div>
                               <div><img src="<?php echo get_template_directory_uri(); ?>/images/slider_img_3.png"
                                       alt="Modern Villa Interior 3" /></div>
                           </div>

                           <!-- RIGHT FADE CONTENT SLIDER -->
                           <div class="right-slider">
                               <div class="right-slide-content">
                                   <div class="simphony_content">
                                       <h2 class="f_36">Workspaces & Offices</h2>
                                       <div class="symphony_tagline">Sleek Modern Transparency</div>
                                       <p>Sleek, modern aesthetic with clean lines and minimal visual interruption. Enhances architectural elegance and maximizes natural light flow.</p>
                                   </div>
                                   <img src="<?php echo get_template_directory_uri(); ?>/images/slider_img_2.png"
                                       class="slide-thumbnail" alt="Thumbnail" />
                               </div>

                               <div class="right-slide-content">
                                   <div class="simphony_content">
                                       <h2 class="f_36">Symfony® Glass</h2>
                                       <div class="symphony_tagline">Sleek Modern Transparency</div>
                                       <p>Symfony® Acoustic Glass Partitions Systems are designed for transparency
                                           without compromise. Symfony® Acoustic Glass partitions bring clarity,
                                           openness, and acoustic control into one seamless system. </p>
                                   </div>
                                   <img src="<?php echo get_template_directory_uri(); ?>/images/slider_img_3.png"
                                       class="slide-thumbnail" alt="Thumbnail" />
                               </div>

                               <div class="right-slide-content">
                                   <div class="simphony_content">
                                       <h2 class="f_36">Symfony® Glass</h2>
                                       <div class="symphony_tagline">Sleek Modern Transparency</div>
                                       <p>Symfony® Acoustic Glass Partitions Systems are designed for transparency
                                           without compromise. Symfony® Acoustic Glass partitions bring clarity,
                                           openness, and acoustic control into one seamless system. </p>
                                   </div>

                                   <img src="<?php echo get_template_directory_uri(); ?>/images/slider_img_1.png"
                                       class="slide-thumbnail" alt="Thumbnail" />
                               </div>

                           </div>
                           <div class="dots-wrap"></div>
                       </div>

                   </div>
               </div>