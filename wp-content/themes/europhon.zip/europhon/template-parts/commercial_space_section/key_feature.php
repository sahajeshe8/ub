

<section class="key_feature pt_150 pb_150">
    <div class="container">
        <div class="text_center">
             <h2 class="f_56 text_center" data-aos="fade-up" data-aos-duration="1200" data-aos-once="true">KEY FEATURES</h2>
            <p class="f_18 mt_20" data-aos="fade-up" data-aos-duration="1200" data-aos-once="true">CRAFTING SILENCE AND STYLE IN EVERY PARTITION</p>
        </div>

        <div class="key_feature_grid mt_80">
            <div class="key_feature_box" data-aos="fade-up" data-aos-duration="1200" data-aos-once="true">
                <div class="key_feature_img">
                    <img src="<?php echo get_template_directory_uri(); ?>/images/key_feature_1.png" alt="img">
                </div>
                <div class="key_feature_title">
                    Slim aluminum profiles with
                    frameless glass-to-glass joints
                </div>
            </div>
            <div class="key_feature_box" data-aos="fade-up" data-aos-duration="1200" data-aos-once="true">
                <div class="key_feature_img">
                    <img src="<?php echo get_template_directory_uri(); ?>/images/key_feature_2.png" alt="img">
                </div>
                <div class="key_feature_title">
                   Acoustic performance tailored
                    to project requirements
                </div>
            </div>
            <div class="key_feature_box" data-aos="fade-up" data-aos-duration="1200" data-aos-once="true">
                <div class="key_feature_img">
                    <img src="<?php echo get_template_directory_uri(); ?>/images/key_feature_3.png" alt="img">
                </div>
                <div class="key_feature_title">
                    Compatible with swing, sliding,
                    and frameless glass doors
                </div>
            </div>
            <div class="key_feature_box" data-aos="fade-up" data-aos-duration="1200" data-aos-once="true">
                <div class="key_feature_img">
                    <img src="<?php echo get_template_directory_uri(); ?>/images/key_feature_4.png" alt="img">
                </div>
                <div class="key_feature_title">
                    Wide range of finishes for frames
                    and accessories
                </div>
            </div>
            <div class="key_feature_box" data-aos="fade-up" data-aos-duration="1200" data-aos-once="true">
                <div class="key_feature_img">
                    <img src="<?php echo get_template_directory_uri(); ?>/images/key_feature_5.png" alt="img">
                </div>
                <div class="key_feature_title">
                    Light-filled spaces with controlled
                    acoustic comfort
                </div>
            </div>
        </div>
    </div>
</section>