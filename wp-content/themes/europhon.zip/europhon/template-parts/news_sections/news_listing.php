

<section class="news_listing_wrap pt_150 pb_150">
    <div class="container">
        <div class="filter_search search-bar">
    <div class="search-field">
        <button class="icon_search"><img src="<?php echo get_template_directory_uri(); ?>/images/search_filter.svg" alt="img"></button>
        <input type="text" placeholder="SEARCH">
    </div>

    <div class="category-field">
<div class="select_cate">
    <select name="categories" id="category">
        <option value="category1" selected>Category</option>
        <option value="category2">Category 1</option>
        <option value="category3">Category 2</option>
        <option value="category3">Category 3</option>
        <option value="category3">Category 4</option>
    </select>

    <!-- SVG Arrow -->
    <span class="select-arrow">
       <img src="<?php echo get_template_directory_uri(); ?>/images/black_dropdown.svg" alt="img">
    </span>
</div>

    </div>

        </div>


        <div class="news_listing_grid">
            <a href="/news-detail" class="news_grid_box" data-aos="fade-up" data-aos-duration="1200" data-aos-once="true">
                <div class="news_gird_img">
                    <img src="<?php echo get_template_directory_uri(); ?>/images/news_img_1.png" alt="img">
                </div>
                <div class="news_date">Jan 24, 2025</div>
                <div class="news_title">
                    3D Acoustic Ceiling Tiles
                </div>
                <p class="f_18">The Symfony Double Glaze Glass Partition with Door is a precision-engineered
                    architectural solution that elevates spatial design The Symfony Double Glaze Glass Partition with
                    The Symfony Double Glaze Glass Partition with Door is a precision-engineered architectural solution
                    that elevates spatial design Door is a precision-engineered architectural solution that elevates
                    spatial design</p>
            </a>

            <a href="/news-detail" class="news_grid_box" data-aos="fade-up" data-aos-duration="1200" data-aos-once="true">
                <div class="news_gird_img">
                    <img src="<?php echo get_template_directory_uri(); ?>/images/news_img_2.png" alt="img">
                </div>
                <div class="news_date">Jan 24, 2025</div>
                <div class="news_title">
                    3D Acoustic Ceiling Tiles
                </div>
                <p class="f_18">The Symfony Double Glaze Glass Partition with Door is a precision-engineered
                    architectural solution that elevates spatial design</p>
            </a>

            <a href="/news-detail" class="news_grid_box" data-aos="fade-up" data-aos-duration="1200" data-aos-once="true">
                <div class="news_gird_img">
                    <img src="<?php echo get_template_directory_uri(); ?>/images/news_img_3.png" alt="img">
                </div>
                <div class="news_date">Jan 24, 2025</div>
                <div class="news_title">
                    3D Acoustic Ceiling Tiles
                </div>
                <p class="f_18">The Symfony Double Glaze Glass Partition with Door is a precision-engineered
                    architectural solution that elevates spatial design</p>
            </a>

            <a href="/news-detail" class="news_grid_box" data-aos="fade-up" data-aos-duration="1200" data-aos-once="true">
                <div class="news_gird_img">
                    <img src="<?php echo get_template_directory_uri(); ?>/images/news_img_4.png" alt="img">
                </div>
                <div class="news_date">Jan 24, 2025</div>
                <div class="news_title">
                    3D Acoustic Ceiling Tiles
                </div>
                <p class="f_18">The Symfony Double Glaze Glass Partition with Door is a precision-engineered
                    architectural solution that elevates spatial design</p>
            </a>

            <a href="/news-detail" class="news_grid_box" data-aos="fade-up" data-aos-duration="1200" data-aos-once="true">
                <div class="news_gird_img">
                    <img src="<?php echo get_template_directory_uri(); ?>/images/news_img_5.png" alt="img">
                </div>
                <div class="news_date">Jan 24, 2025</div>
                <div class="news_title">
                    3D Acoustic Ceiling Tiles
                </div>
                <p class="f_18">The Symfony Double Glaze Glass Partition with Door is a precision-engineered
                    architectural solution that elevates spatial design</p>
            </a>

            <a href="/news-detail" class="news_grid_box" data-aos="fade-up" data-aos-duration="1200" data-aos-once="true">
                <div class="news_gird_img">
                    <img src="<?php echo get_template_directory_uri(); ?>/images/news_img_6.png" alt="img">
                </div>
                <div class="news_date">Jan 24, 2025</div>
                <div class="news_title">
                    3D Acoustic Ceiling Tiles
                </div>
                <p class="f_18">The Symfony Double Glaze Glass Partition with Door is a precision-engineered
                    architectural solution that elevates spatial design</p>
            </a>

            <a href="/news-detail" class="news_grid_box" data-aos="fade-up" data-aos-duration="1200" data-aos-once="true">
                <div class="news_gird_img">
                    <img src="<?php echo get_template_directory_uri(); ?>/images/news_img_7.png" alt="img">
                </div>
                <div class="news_date">Jan 24, 2025</div>
                <div class="news_title">
                    3D Acoustic Ceiling Tiles
                </div>
                <p class="f_18">The Symfony Double Glaze Glass Partition with Door is a precision-engineered
                    architectural solution that elevates spatial design</p>
            </a>

            <a href="/news-detail" class="news_grid_box" data-aos="fade-up" data-aos-duration="1200" data-aos-once="true">
                <div class="news_gird_img">
                    <img src="<?php echo get_template_directory_uri(); ?>/images/news_img_8.png" alt="img">
                </div>
                <div class="news_date">Jan 24, 2025</div>
                <div class="news_title">
                    3D Acoustic Ceiling Tiles
                </div>
                <p class="f_18">The Symfony Double Glaze Glass Partition with Door is a precision-engineered
                    architectural solution that elevates spatial design</p>
            </a>

            <a href="/news-detail" class="news_grid_box" data-aos="fade-up" data-aos-duration="1200" data-aos-once="true">
                <div class="news_gird_img">
                    <img src="<?php echo get_template_directory_uri(); ?>/images/news_img_9.png" alt="img">
                </div>
                <div class="news_date">Jan 24, 2025</div>
                <div class="news_title">
                    3D Acoustic Ceiling Tiles
                </div>
                <p class="f_18">The Symfony Double Glaze Glass Partition with Door is a precision-engineered
                    architectural solution that elevates spatial design</p>
            </a>

            <a href="/news-detail" class="news_grid_box" data-aos="fade-up" data-aos-duration="1200" data-aos-once="true">
                <div class="news_gird_img">
                    <img src="<?php echo get_template_directory_uri(); ?>/images/news_img_10.png" alt="img">
                </div>
                <div class="news_date">Jan 24, 2025</div>
                <div class="news_title">
                    3D Acoustic Ceiling Tiles
                </div>
                <p class="f_18">The Symfony Double Glaze Glass Partition with Door is a precision-engineered
                    architectural solution that elevates spatial design</p>
            </a>
        </div>
    </div>
</section>