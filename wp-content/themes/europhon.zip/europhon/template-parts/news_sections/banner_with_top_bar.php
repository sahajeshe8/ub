<section class="sub_page_banner small_banner radial_gradient" style="background-image: url('<?php echo get_template_directory_uri(); ?>/images/news_page_banner.webp');">
    <div class="container">

      <div class="banner_nav_wraper">
<!--         <div class="banner_bread_crumb">
            <div class="banner_bc_title" data-aos="fade-right" data-aos-duration="1400" data-aos-once="true">About Us</div>
        </div> -->
         <div class="banner_content text_center">
        <h1 class="f_56 color_white" data-aos="fade-up" data-aos-duration="1400" data-aos-once="true">News</h1>
       </div>

      </div>
    </div>
</section>