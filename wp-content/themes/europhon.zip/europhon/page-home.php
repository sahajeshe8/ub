<?php 
/* Template Name: Home */

get_header();?>


            <?php get_template_part('template-parts/home_sections/home_banner_1'); ?>
			<?php get_template_part('template-parts/home_sections/home_about'); ?>
			<?php get_template_part('template-parts/home_sections/home_slider'); ?>
			<?php// get_template_part('template-parts/home_sections/home_slider_new'); ?>
 

<?php get_footer();?>