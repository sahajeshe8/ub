/* =========================
   Home Slider New - Swiper Initialization
========================== */

document.addEventListener('DOMContentLoaded', function() {
    // Check if Swiper is loaded
    if (typeof Swiper === 'undefined') {
        console.error('Swiper library is not loaded');
        return;
    }
    
    var isSyncing = false; // Flag to prevent infinite sync loops
    var sliderCol01, sliderCol02, sliderCol03;
    
    // Function to sync all sliders
    function syncAllSliders(activeIndex, sourceSlider) {
        if (isSyncing) return;
        isSyncing = true;
        
        if (sliderCol01 && sourceSlider !== sliderCol01) {
            sliderCol01.slideToLoop(activeIndex);
        }
        if (sliderCol02 && sourceSlider !== sliderCol02) {
            sliderCol02.slideToLoop(activeIndex);
        }
        if (sliderCol03 && sourceSlider !== sliderCol03) {
            sliderCol03.slideToLoop(activeIndex);
        }
        
        setTimeout(function() {
            isSyncing = false;
        }, 100);
    }
    
    // Initialize Swiper for column 01
    sliderCol01 = new Swiper('.slider-col-01', {
        slidesPerView: 1,
        speed: 800,
        loop: true,
        autoplay: {
            delay: 3000,
            disableOnInteraction: false,
        },
        navigation: {
            nextEl: '.slider-col-01 .swiper-button-next',
            prevEl: '.slider-col-01 .swiper-button-prev',
        },
        on: {
            slideChange: function() {
                if (!isSyncing) {
                    syncAllSliders(this.realIndex, this);
                }
                if (updatePaginationButtons) {
                    updatePaginationButtons(this.realIndex);
                }
            }
        }
    });

    // Initialize Swiper for column 02
    sliderCol02 = new Swiper('.slider-col-02', {
        slidesPerView: 1,
        spaceBetween: 30,
        speed: 800,
        loop: true,
        autoplay: {
            delay: 3000,
            disableOnInteraction: false,
        },
        navigation: {
            nextEl: '.slider-col-02 .swiper-button-next',
            prevEl: '.slider-col-02 .swiper-button-prev',
        },
        on: {
            slideChange: function() {
                if (!isSyncing) {
                    syncAllSliders(this.realIndex, this);
                }
                if (updatePaginationButtons) {
                    updatePaginationButtons(this.realIndex);
                }
            }
        }
    });

    // Initialize Swiper for column 03
    sliderCol03 = new Swiper('.slider-col-03', {
        slidesPerView: 1,
        spaceBetween: 30,
        speed: 800,
        loop: true,
        autoplay: {
            delay: 3000,
            disableOnInteraction: false,
        },
        navigation: {
            nextEl: '.slider-col-03 .swiper-button-next',
            prevEl: '.slider-col-03 .swiper-button-prev',
        },
        on: {
            slideChange: function() {
                if (!isSyncing) {
                    syncAllSliders(this.realIndex, this);
                }
                if (updatePaginationButtons) {
                    updatePaginationButtons(this.realIndex);
                }
            }
        }
    });

    // Create shared pagination
    var sharedPagination = document.querySelector('.shared-pagination');
    var updatePaginationButtons;
    
    if (sharedPagination) {
        // Count original slides from HTML (before Swiper duplicates them for loop)
        var originalSlides = document.querySelectorAll('.slider-col-01 .swiper-slide').length;
        var slideCount = originalSlides;
        
        // Create pagination buttons
        for (var i = 0; i < slideCount; i++) {
            var button = document.createElement('button');
            button.className = 'pagination-btn';
            if (i === 0) button.classList.add('active');
            button.setAttribute('data-slide', i);
            button.setAttribute('aria-label', 'Go to slide ' + (i + 1));
            sharedPagination.appendChild(button);
            
            // Add click event
            button.addEventListener('click', function() {
                var slideIndex = parseInt(this.getAttribute('data-slide'));
                syncAllSliders(slideIndex, null);
            });
        }
        
        // Function to update pagination buttons
        updatePaginationButtons = function(activeIndex) {
            var buttons = sharedPagination.querySelectorAll('.pagination-btn');
            buttons.forEach(function(btn, index) {
                if (index === activeIndex) {
                    btn.classList.add('active');
                } else {
                    btn.classList.remove('active');
                }
            });
        };
    }
});

