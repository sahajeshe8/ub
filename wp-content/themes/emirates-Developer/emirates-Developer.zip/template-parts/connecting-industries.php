<?php
/**
 * Banner Component Template
 *
 * @package tasheel
 */

?>

 
	 <!-- <div class="global_brands_content_title pb_30">
				<h3 class="h3_title_55 text_black">
				Connecting Industries with <br/>Innovation and Quality
				</h3>
				<a href="" class="btn_style me-1 buttion_blue">Explore Industries</a>
			</div> -->



<div class="connecting_industries_content">
<div class="p-wrap">
                <div class="panel_img   h_100vh" style=" background: red; background-size: cover;">
                  
                </div> 
                <div class="panel_img blue h_100vh" style="  background: blue; background-size: cover;">
                  dsdsd
                </div> 
                <div class="panel_img blue h_100vh" style="  background: red; background-size: cover;">
                  
                </div> 

                 <div class="panel_img blue h_100vh" style="  background:blue; background-size: cover;">
                  
                </div> 

                 <div class="panel_img blue h_100vh" style="  background:red; background-size: cover;">
                  
                </div> 
                
            </div>
</div>




 