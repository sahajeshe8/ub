<?php
/**
 * Products Component Template
 *
 * @package tasheel
 */

?>

<section class="pt_80 pb_80 innovative_products_section">
	<div class="wrap">


 
	<div class="product_overview_content mb_30" data-aos="fade-up" data-aos-duration="800" data-aos-delay="100" data-aos-once="true">
			<div class="product_overview_title">
				<h2 class="h3_title">CABLE & CABLE ACCESSORIES</h2>

				<div>
				
				</div>
			</div>
						<div class="product_overview_description">
						<div class="filter_by">
						<span class="filter_by_label">Filters by:</span>  
						
						<select name="" id="" class="filter_select">
						<option value="">1</option>
						<option value="">2</option>
						<option value="">3</option>
						<option value="">4</option>
						<option value="">5</option>
					</select>
					</div>
						</div>
						
			
		</div>



		<ul class="products_list style-02 style-03">
			<?php
			$product_items = array(
				array('img' => 'pro-c-01.jpg', 'title' => 'Fire Resistant Cable'),
				array('img' => 'pro-c-02.jpg', 'title' => 'Paired Cable'),
				array('img' => 'pro-c-03.jpg', 'title' => 'Multi Conductor Cable'),
				array('img' => 'pro-c-04.jpg', 'title' => 'Instrumentation Cable'),
				array('img' => 'pro-c-11.jpg', 'title' => 'Low Voltage Cables'),
				array('img' => 'pro-c-06.jpg', 'title' => 'Wires'),
				array('img' => 'pro-c-10.jpg', 'title' => 'Control Cables'),
				array('img' => 'pro-c-09.jpg', 'title' => 'Low Voltage Power Cables(MESC)'),
				array('img' => 'pro-c-12.jpg', 'title' => 'Single Core Cable/ Building Wire'),
				array('img' => 'pro-c-07.jpg', 'title' => 'Flexible Cable'),
				array('img' => 'pro-c-05.jpg', 'title' => 'Single Core Cable'),
				array('img' => 'pro-c-08.jpg', 'title' => 'Low Voltage Power Cables'),
				array('img' => 'prod-c-15.jpg', 'title' => 'Stranded Wires'),
				array('img' => 'prod-c-17.jpg', 'title' => 'Multi Core'),
				array('img' => 'prod-c-16.jpg', 'title' => 'Panel Cables'),
				array('img' => 'prod-c-23.jpg', 'title' => 'Rubber Cables'),
				array('img' => 'prod-c-22.jpg', 'title' => 'PVC FLEXIBLE CABLE HO5VV-F'),
                array('img' => 'prod-c-21.jpg', 'title' => 'CAT-6 Cable'),
                array('img' => 'prod-c-20.jpg', 'title' => 'Cable Lugs'),
				array('img' => 'prod-c-19.jpg', 'title' => 'Cable Lugs - BI Metal'),
                array('img' => 'prod-c-18.jpg', 'title' => 'CW BRASS CABLE GLANDS'),
                array('img' => '', 'title' => 'Cable Glands-BW Brass'),
                array('img' => 'prod-c-25.jpg', 'title' => 'Cable Glands-A1 A2'),
                array('img' => 'prod-c-24.jpg', 'title' => 'E1W Gland FOR SWA CABLE'),
                array('img' => 'prod-c-13.jpg', 'title' => 'CABLE GLANDS'),
                array('img' => 'prod-c-14.jpg', 'title' => 'CABLELUGS & CONNECTION'),
                array('img' => '', 'title' => 'CABLE CLIPS - ROUND'),
				array('img' => '', 'title' => 'CABLE TIE'),
				array('img' => '', 'title' => 'SELF ADHESIVE MOUNTS'),
				array('img' => '', 'title' => 'GROMMET-OPEN & CLOSE'),
				array('img' => '', 'title' => 'EDGING GROMMET'),
				array('img' => '', 'title' => 'HEAT SHRINK'),
				array('img' => '', 'title' => 'SPIRAL BINDING'),
				array('img' => '', 'title' => 'CORD END TERMINALS'),
				array('img' => '', 'title' => 'SPADE(FORK) TERMINALS'),
				array('img' => 'prod-c-26.jpg', 'title' => 'RING TERMINALS'),
				array('img' => 'prod-c-32.jpg', 'title' => 'PG GLANDS'),
				array('img' => 'prod-c-30.jpg', 'title' => 'SUPREME METRIC GLAND- IP68'),
				array('img' => 'prod-c-29.jpg', 'title' => 'SUPREME PG GLAND - IP68'),
				array('img' => 'prod-c-31.jpg', 'title' => 'SPLIT FLEXIBLE COUNDUITS'),
				array('img' => 'prod-c-28.jpg', 'title' => 'GM CABLE MARKER'),
				array('img' => 'prod-c-31.jpg', 'title' => 'MARKER STRIPS'),
				array('img' => 'prod-c-27.jpg', 'title' => 'BM CABLR MARKER'),
			);
			$delay = 200;
			foreach ($product_items as $index => $item) :
				$current_delay = $delay + ($index * 50);
			?>
			<li data-aos="fade-up" data-aos-duration="800" data-aos-delay="<?php echo $current_delay; ?>" data-aos-once="true">
				<div class="product_item">
					<div class="product_item_img">
						<img src="<?php echo get_template_directory_uri(); ?>/assets/images/<?php echo esc_attr( $item['img'] ); ?>" alt="<?php echo esc_attr( $item['title'] ); ?>">
					</div>
					<div class="global_logo_box_bottom">
						<div>
							<h4><?php echo esc_html( $item['title'] ); ?></h4>
							<h3>Lorem ipsum dolor sit amet, consectetur adipiscing.</h3>
						</div>
						<a href="<?php echo esc_url( home_url( '/product-detail' ) ); ?>" class="global_buttion">
							<img src="<?php echo get_template_directory_uri(); ?>/assets/images/arrow_01.svg" alt="RAMCRO">
						</a>
					</div>
				</div>
			</li>
			<?php endforeach; ?>

		 
 

	 










 

		</ul>

		<div class="load_more_btn_row" data-aos="fade-up" data-aos-duration="800" data-aos-delay="650" data-aos-once="true">
		<a href="" class="btn_style me-1 buttion_blue">Load more</a>
		</div>
	</div>
</section>
